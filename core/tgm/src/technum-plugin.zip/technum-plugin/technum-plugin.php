<?php
/*
Plugin Name: TechnUm Plugin
Plugin URI: https://demo.artureanec.com/
Description: Register Custom Widgets and Custom Post Types for TechnUm Theme.
Version: 1.0.3
Author: Artureanec
Author URI: https://demo.artureanec.com/
Text Domain: technum_plugin
*/

// --- Register Custom Widgets --- //
if (!function_exists('technum_widgets_load')) {
    function technum_widgets_load() {
        require_once(__DIR__ . "/widgets/banner.php");
        require_once(__DIR__ . "/widgets/contacts.php");
        require_once(__DIR__ . "/widgets/featured-posts.php");
        require_once(__DIR__ . "/widgets/nav-menu.php");
    }
}
add_action('plugins_loaded', 'technum_widgets_load');

if (!function_exists('technum_add_custom_widget')) {
    function technum_add_custom_widget($name) {
        register_widget($name);
    }
}

// --- Register Custom Post Types --- //
add_action('init', 'technum_register_custom_post_types');
if (!function_exists('technum_register_custom_post_types')) {
    function technum_register_custom_post_types() {
        # Portfolio
        register_taxonomy(
            'technum_portfolio_category',
            array('technum_portfolio'),
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Portfolio Categories', 'technum_plugin'),
                    'singular_name'     => esc_html__('Portfolio Category', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Category', 'technum_plugin'),
                    'all_items'         => esc_html__('All Portfolio Categories', 'technum_plugin'),
                    'view_item'         => esc_html__('View Category', 'technum_plugin'),
                    'parent_item'       => esc_html__('Parent Category', 'technum_plugin'),
                    'parent_item_colon' => esc_html__('Parent Category:', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Category', 'technum_plugin'),
                    'update_item'       => esc_html__('Update Category', 'technum_plugin'),
                    'add_new_item'      => esc_html__('Add New Category', 'technum_plugin'),
                    'new_item_name'     => esc_html__('New Portfolio Category', 'technum_plugin'),
                    'menu_name'         => esc_html__('Portfolio Categories', 'technum_plugin'),
                ),
                'hierarchical'      => true,
                'show_admin_column' => false
            )
        );
        register_post_type(
            'technum_portfolio',
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Portfolios', 'technum_plugin'),
                    'singular_name'     => esc_html__('Portfolio', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Portfolio', 'technum_plugin'),
                    'all_items'         => esc_html__('All Portfolios', 'technum_plugin'),
                    'view_item'         => esc_html__('View Portfolio', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Portfolio', 'technum_plugin'),
                    'add_new'           => esc_html__('Add New Portfolio', 'technum_plugin'),
                    'add_new_item'      => esc_html__('New Portfolio', 'technum_plugin'),
                    'archives'          => esc_html__('Portfolios', 'technum_plugin')
                ),
                'public'            => true,
                'rewrite'           => array(
                    'slug'              => 'portfolio',
                    'with_front'        => false
                ),
                'hierarchical'      => true,
                'menu_position'     => 4,
                'menu_icon'         => 'dashicons-format-gallery',
                'supports'          => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
                'taxonomies'        => array( 'technum_portfolio_category' ),
                'has_archive'       => true
            )
        );

        # Projects
        register_taxonomy(
            'technum_project_category',
            array('technum_project'),
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Project Categories', 'technum_plugin'),
                    'singular_name'     => esc_html__('Project Category', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Category', 'technum_plugin'),
                    'all_items'         => esc_html__('All Project Categories', 'technum_plugin'),
                    'view_item'         => esc_html__('View Category', 'technum_plugin'),
                    'parent_item'       => esc_html__('Parent Category', 'technum_plugin'),
                    'parent_item_colon' => esc_html__('Parent Category:', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Category', 'technum_plugin'),
                    'update_item'       => esc_html__('Update Category', 'technum_plugin'),
                    'add_new_item'      => esc_html__('Add New Category', 'technum_plugin'),
                    'new_item_name'     => esc_html__('New Project Category', 'technum_plugin'),
                    'menu_name'         => esc_html__('Project Categories', 'technum_plugin'),
                ),
                'hierarchical'      => true,
                'show_admin_column' => false
            )
        );
        register_post_type(
            'technum_project',
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Projects', 'technum_plugin'),
                    'singular_name'     => esc_html__('Project', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Project', 'technum_plugin'),
                    'all_items'         => esc_html__('All Projects', 'technum_plugin'),
                    'view_item'         => esc_html__('View Project', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Project', 'technum_plugin'),
                    'add_new'           => esc_html__('Add New Project', 'technum_plugin'),
                    'add_new_item'      => esc_html__('New Project', 'technum_plugin'),
                    'archives'          => esc_html__('Projects', 'technum_plugin')
                ),
                'public'            => true,
                'rewrite'           => array(
                    'slug'              => 'projects',
                    'with_front'        => false
                ),
                'hierarchical'      => true,
                'menu_position'     => 5,
                'menu_icon'         => 'dashicons-laptop',
                'supports'          => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
                'taxonomies'        => array( 'technum_project_category' ),
                'has_archive'       => true
            )
        );

        # Team
        register_taxonomy(
            'technum_team_department',
            array('technum_team_member'),
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Departments', 'technum_plugin'),
                    'singular_name'     => esc_html__('Department', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Departments', 'technum_plugin'),
                    'all_items'         => esc_html__('All Departments', 'technum_plugin'),
                    'view_item'         => esc_html__('View Department', 'technum_plugin'),
                    'parent_item'       => esc_html__('Parent Department', 'technum_plugin'),
                    'parent_item_colon' => esc_html__('Parent Department:', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Department', 'technum_plugin'),
                    'update_item'       => esc_html__('Update Department', 'technum_plugin'),
                    'add_new_item'      => esc_html__('Add New Department', 'technum_plugin'),
                    'new_item_name'     => esc_html__('New Department Name', 'technum_plugin'),
                    'menu_name'         => esc_html__('Departments', 'technum_plugin'),
                ),
                'hierarchical'      => true,
                'show_admin_column' => false
            )
        );
        register_post_type('technum_team_member',
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Team Members', 'technum_plugin'),
                    'singular_name'     => esc_html__('Team Member', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Team Member', 'technum_plugin'),
                    'all_items'         => esc_html__('All Team Members', 'technum_plugin'),
                    'view_item'         => esc_html__('View Team Member', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Team Member', 'technum_plugin'),
                    'add_new'           => esc_html__('Add New Member', 'technum_plugin'),
                    'add_new_item'      => esc_html__('New Team Member', 'technum_plugin'),
                    'archives'          => esc_html__('Team', 'technum_plugin')
                ),
                'public'            => true,
                'rewrite'           => array(
                    'slug'              => 'team',
                    'with_front'        => false
                ),
                'hierarchical'      => false,
                'menu_position'     => 6,
                'menu_icon'         => 'dashicons-groups',
                'supports'          => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
                'taxonomies'        => array( 'technum_team_department' ),
                'has_archive'       => true
            )
        );

        # Careers
        register_taxonomy(
            'technum_careers_department',
            array('technum_vacancy'),
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Departments', 'technum_plugin'),
                    'singular_name'     => esc_html__('Department', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Departments', 'technum_plugin'),
                    'all_items'         => esc_html__('All Departments', 'technum_plugin'),
                    'view_item'         => esc_html__('View Department', 'technum_plugin'),
                    'parent_item'       => esc_html__('Parent Department', 'technum_plugin'),
                    'parent_item_colon' => esc_html__('Parent Department:', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Department', 'technum_plugin'),
                    'update_item'       => esc_html__('Update Department', 'technum_plugin'),
                    'add_new_item'      => esc_html__('Add New Department', 'technum_plugin'),
                    'new_item_name'     => esc_html__('New Department Name', 'technum_plugin'),
                    'menu_name'         => esc_html__('Departments', 'technum_plugin'),
                ),
                'hierarchical'      => true,
                'show_admin_column' => false
            )
        );
        register_post_type('technum_vacancy',
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Vacancies', 'technum_plugin'),
                    'singular_name'     => esc_html__('Vacancy', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Vacancy', 'technum_plugin'),
                    'all_items'         => esc_html__('All Vacancies', 'technum_plugin'),
                    'view_item'         => esc_html__('View Vacancy', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Vacancy', 'technum_plugin'),
                    'add_new'           => esc_html__('Add New Vacancy', 'technum_plugin'),
                    'add_new_item'      => esc_html__('New Vacancy', 'technum_plugin'),
                    'archives'          => esc_html__('Careers', 'technum_plugin')
                ),
                'public'            => true,
                'rewrite'           => array(
                    'slug'              => 'careers',
                    'with_front'        => false
                ),
                'hierarchical'      => false,
                'menu_position'     => 7,
                'menu_icon'         => 'dashicons-megaphone',
                'supports'          => array( 'title', 'editor', 'author', 'excerpt' ),
                'taxonomies'        => array( 'technum_careers_department' ),
                'has_archive'       => true
            )
        );

        # Services
        register_taxonomy(
            'technum_services_category',
            array('technum_service'),
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Service Categories', 'technum_plugin'),
                    'singular_name'     => esc_html__('Service Category', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Category', 'technum_plugin'),
                    'all_items'         => esc_html__('All Categories', 'technum_plugin'),
                    'view_item'         => esc_html__('View Category', 'technum_plugin'),
                    'parent_item'       => esc_html__('Parent Category', 'technum_plugin'),
                    'parent_item_colon' => esc_html__('Parent Category:', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Category', 'technum_plugin'),
                    'update_item'       => esc_html__('Update Category', 'technum_plugin'),
                    'add_new_item'      => esc_html__('Add New Category', 'technum_plugin'),
                    'new_item_name'     => esc_html__('New Category Name', 'technum_plugin'),
                    'menu_name'         => esc_html__('Categories', 'technum_plugin'),
                ),
                'hierarchical'      => true,
                'show_admin_column' => false
            )
        );
        register_post_type('technum_service',
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Services', 'technum_plugin'),
                    'singular_name'     => esc_html__('Service', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Service', 'technum_plugin'),
                    'all_items'         => esc_html__('All Services', 'technum_plugin'),
                    'view_item'         => esc_html__('View Service', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Service', 'technum_plugin'),
                    'add_new'           => esc_html__('Add New Service', 'technum_plugin'),
                    'add_new_item'      => esc_html__('New Service', 'technum_plugin'),
                    'archives'          => esc_html__('Services', 'technum_plugin')
                ),
                'public'            => true,
                'rewrite'           => array(
                    'slug'              => 'services',
                    'with_front'        => false
                ),
                'hierarchical'      => false,
                'menu_position'     => 8,
                'menu_icon'         => 'dashicons-admin-generic',
                'supports'          => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
                'taxonomies'        => array( 'technum_services_category' ),
                'has_archive'       => true
            )
        );

        # Case Studies
        register_taxonomy(
            'technum_case_study_category',
            array('technum_case_study'),
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Case Study Categories', 'technum_plugin'),
                    'singular_name'     => esc_html__('Case Study Category', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Category', 'technum_plugin'),
                    'all_items'         => esc_html__('All Categories', 'technum_plugin'),
                    'view_item'         => esc_html__('View Category', 'technum_plugin'),
                    'parent_item'       => esc_html__('Parent Category', 'technum_plugin'),
                    'parent_item_colon' => esc_html__('Parent Category:', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Category', 'technum_plugin'),
                    'update_item'       => esc_html__('Update Category', 'technum_plugin'),
                    'add_new_item'      => esc_html__('Add New Category', 'technum_plugin'),
                    'new_item_name'     => esc_html__('New Category Name', 'technum_plugin'),
                    'menu_name'         => esc_html__('Categories', 'technum_plugin'),
                ),
                'hierarchical'      => true,
                'show_admin_column' => false,
                'show_in_rest'      => true
            )
        );
        register_taxonomy(
            'technum_case_study_tag',
            array('technum_case_study'),
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Case Study Tags', 'technum_plugin'),
                    'singular_name'     => esc_html__('Case Study Tag', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Tag', 'technum_plugin'),
                    'all_items'         => esc_html__('All Tags', 'technum_plugin'),
                    'view_item'         => esc_html__('View Tag', 'technum_plugin'),
                    'parent_item'       => esc_html__('Parent Tag', 'technum_plugin'),
                    'parent_item_colon' => esc_html__('Parent Tag:', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Tag', 'technum_plugin'),
                    'update_item'       => esc_html__('Update Tag', 'technum_plugin'),
                    'add_new_item'      => esc_html__('Add New Tag', 'technum_plugin'),
                    'new_item_name'     => esc_html__('New Tag Name', 'technum_plugin'),
                    'menu_name'         => esc_html__('Tags', 'technum_plugin'),
                ),
                'hierarchical'      => false,
                'show_admin_column' => false,
                'show_in_rest'      => true
            )
        );
        register_post_type('technum_case_study',
            array(
                'label'             => null,
                'labels'            => array(
                    'name'              => esc_html__('Case Studies', 'technum_plugin'),
                    'singular_name'     => esc_html__('Case Study', 'technum_plugin'),
                    'search_items'      => esc_html__('Search Case Studies', 'technum_plugin'),
                    'all_items'         => esc_html__('All Case Studies', 'technum_plugin'),
                    'view_item'         => esc_html__('View Case Study', 'technum_plugin'),
                    'edit_item'         => esc_html__('Edit Case Study', 'technum_plugin'),
                    'add_new'           => esc_html__('Add New Case Study', 'technum_plugin'),
                    'add_new_item'      => esc_html__('New Case Study', 'technum_plugin'),
                    'archives'          => esc_html__('Case Studies', 'technum_plugin')
                ),
                'public'            => true,
                'rewrite'           => array(
                    'slug'              => 'case-studies',
                    'with_front'        => false
                ),
                'hierarchical'      => false,
                'menu_position'     => 9,
                'menu_icon'         => 'dashicons-open-folder',
                'supports'          => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
                'taxonomies'        => array( 'technum_case_study_category' ),
                'has_archive'       => true,
                'show_in_rest'      => true
            )
        );

    }
}

// Init Custom Widgets for Elementor
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

final class TechnUm_Custom_Widgets {
    const  VERSION = '1.0.0';
    const  MINIMUM_ELEMENTOR_VERSION = '2.0.0';
    const  MINIMUM_PHP_VERSION = '5.4';
    private static $_instance = null;

    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        add_action('plugins_loaded', [$this, 'init']);
    }

    public function i18n() {
        load_plugin_textdomain('technum_plugin', false, plugin_basename(dirname(__FILE__)) . '/languages');
    }

    public function init() {
        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'technum_admin_notice_missing_main_plugin']);
            return;
        }

        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
            add_action('admin_notices', [$this, 'technum_admin_notice_minimum_elementor_version']);
            return;
        }

        // Check for required PHP version
        if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
            add_action('admin_notices', [$this, 'technum_admin_notice_minimum_php_version']);
            return;
        }

        // Add Custom Fonts Group
        if ( !function_exists('technum_add_custom_fonts_group_to_elementor') ) {
            function technum_add_custom_fonts_group_to_elementor($font_groups) {
                $additional_groups = array(
                    'theme_fonts'     => esc_html__( 'Theme Fonts', 'technum_plugin' )
                );
                $font_groups = array_merge($font_groups, $additional_groups);
                return $font_groups;
            }
        }
        add_filter( 'elementor/fonts/groups', 'technum_add_custom_fonts_group_to_elementor' );

        // Add Custom Fonts
        if ( !function_exists('technum_add_custom_fonts_to_elementor') ) {
            function technum_add_custom_fonts_to_elementor($fonts) {
                $additional_fonts = array();
                $fonts = array_merge($fonts, $additional_fonts);
                return $fonts;
            }
        }
        add_filter( 'elementor/fonts/additional_fonts', 'technum_add_custom_fonts_to_elementor' );

        // Include Additional Files
        add_action('elementor/init', [$this, 'technum_include_additional_files']);

        // Add new Elementor Categories
        add_action('elementor/init', [$this, 'technum_add_elementor_category']);

        // Register Widget Scripts
        add_action('elementor/frontend/after_register_scripts', [$this, 'technum_register_widget_scripts']);

        add_action('wp_enqueue_scripts', function () {
            wp_localize_script('ajax_query_products', 'technum_ajaxurl',
                array(
                    'url' => admin_url('admin-ajax.php')
                )
            );
        });

        // Register New Widgets
        add_action('elementor/widgets/widgets_registered', [$this, 'technum_widgets_register']);

        // Register Editor Styles
        add_action('elementor/editor/before_enqueue_scripts', function () {
            wp_register_style('technum_elementor_admin', plugins_url('technum-plugin/css/technum-plugin-admin.css'));
            wp_enqueue_style('technum_elementor_admin');
        });
    }


    public function technum_admin_notice_missing_main_plugin() {
        $message = sprintf(
        /* translators: 1: Restbeef Core 2: Elementor */
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'technum_plugin'),
            '<strong>' . esc_html__('Restbeef Core', 'technum_plugin') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'technum_plugin') . '</strong>'
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function technum_admin_notice_minimum_elementor_version() {
        $message = sprintf(
        /* translators: 1: Restbeef Core 2: Elementor 3: Required Elementor version */
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'technum_plugin'),
            '<strong>' . esc_html__('Restbeef Core', 'technum_plugin') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'technum_plugin') . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function technum_admin_notice_minimum_php_version() {
        $message = sprintf(
        /* translators: 1: Press Elements 2: PHP 3: Required PHP version */
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'technum_plugin'),
            '<strong>' . esc_html__('Press Elements', 'technum_plugin') . '</strong>',
            '<strong>' . esc_html__('PHP', 'technum_plugin') . '</strong>',
            self::MINIMUM_PHP_VERSION
        );
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function technum_include_additional_files() {}

    public function technum_add_elementor_category() {
        $categories = [];
        $categories['technum_widgets'] = [
            'title' => esc_html__('TechnUm Widgets', 'technum_plugin'),
            'icon'  => 'eicon-plug'
        ];
        $old_categories = \Elementor\Plugin::$instance->elements_manager->get_categories();
        $categories     = array_merge($categories, $old_categories);

        $set_categories = function ( $categories ) {
            $this->categories = $categories;
        };
        $set_categories->call( \Elementor\Plugin::$instance->elements_manager, $categories );
    }

    public function technum_register_widget_scripts() {
        // Lib
        wp_register_script('fancybox', plugins_url('technum-plugin/js/lib/jquery.fancybox.min.js'), array('jquery'));
        wp_register_script('slick-slider', plugins_url('technum-plugin/js/lib/slick.min.js'), array('jquery'));
        wp_register_script('isotope', plugins_url('technum-plugin/js/lib/isotope.pkgd.min.js'), array('jquery'));
        wp_register_script('plugin', plugins_url('technum-plugin/js/lib/jquery.plugin.js'), array('jquery'));

        // Scripts
        wp_register_script('elementor_widgets', plugins_url('technum-plugin/js/elementor-widgets.js'), array('jquery', 'owl-carousel', 'isotope', 'technum-theme'));
    }

    public function technum_widgets_register() {

        // --- Include Widget Files --- //
        require_once __DIR__ . '/elements/blog.php';
        require_once __DIR__ . '/elements/button.php';
        require_once __DIR__ . '/elements/case-study-listing.php';
        require_once __DIR__ . '/elements/content-slider.php';
        require_once __DIR__ . '/elements/custom-menu.php';
        require_once __DIR__ . '/elements/heading.php';
        require_once __DIR__ . '/elements/icon-box.php';
        require_once __DIR__ . '/elements/image-carousel.php';
        require_once __DIR__ . '/elements/portfolio-listing.php';
        require_once __DIR__ . '/elements/price-item.php';
        require_once __DIR__ . '/elements/projects-listing.php';
        require_once __DIR__ . '/elements/special-text.php';
        require_once __DIR__ . '/elements/services-listing.php';
        require_once __DIR__ . '/elements/step.php';
        require_once __DIR__ . '/elements/tabs.php';
        require_once __DIR__ . '/elements/team-members.php';
        require_once __DIR__ . '/elements/testimonial-carousel.php';
        require_once __DIR__ . '/elements/vacancies-listing.php';
        require_once __DIR__ . '/elements/vertical-text.php';

        // --- Register Widgets --- //
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Blog_Listing_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Button_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Case_Study_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Content_Slider_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Custom_Menu_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Heading_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Icon_Box_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Image_Carousel_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Portfolio_Listing_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Price_Item_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Projects_Listing_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Services_Listing_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Special_Text_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Step_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Tabs_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Team_Members_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Testimonial_Carousel_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Vacancies_Listing_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Vertical_Text_Widget());

        if (class_exists('WooCommerce')) {
            require_once __DIR__ . '/elements/products.php';
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Products_Widget());
        }

        if ( function_exists( 'wpforms' ) ) {
            require_once __DIR__ . '/elements/wpforms.php';
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Wpforms_Widget());
        }

        if ( function_exists( 'sb_instagram_feed_init' ) ) {
            require_once __DIR__ . '/elements/instagram-feed.php';
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Instagram_Feed_Widget());
        }

        if ( function_exists( 'mc4wp' ) ) {
            require_once __DIR__ . '/elements/mailchimp.php';
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new TechnUm\Widgets\TechnUm_Mailchimp_Widget());
        }
    }
}

TechnUm_Custom_Widgets::instance();

if ( did_action( 'elementor/loaded' ) ) {
    add_action('elementor/widgets/widgets_registered', function ($widget_manager) {
        $widget_manager->unregister_widget_type('tabs');
    }, 15);

    add_action('elementor/element/before_section_end', function ($element, $section_id, $args) {
        if ('section' === $element->get_name() && 'section_background' === $section_id) {
            $element->add_control(
                'use_parallax',
                [
                    'label'         => esc_html__( 'Parallax Effect', 'plugin-domain' ),
                    'type'          => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'      => esc_html__( 'On', 'your-plugin' ),
                    'label_off'     => esc_html__( 'Off', 'your-plugin' ),
                    'return_value'  => 'yes',
                    'default'       => 'no'
                ]
            );
        }

        if ('progress' === $element->get_name() && 'section_progress' === $section_id) {
            $element->remove_control('inner_text');
            $element->add_control(
                'inner_text',
                [
                    'label'     => esc_html__( 'Hidden Inner Text', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::HIDDEN,
                    'default'   => ''
                ]
            );
        }
        if ('progress' === $element->get_name() && 'section_progress_style' === $section_id) {
            $element->remove_control('bar_color');
            $element->remove_control('bar_bg_color');
            $element->remove_control('bar_height');
            $element->remove_control('bar_border_radius');
            $element->remove_control('inner_text_heading');
            $element->remove_control('bar_inline_color');

            $element->remove_control('bar_inner_typography_typography');
            $element->remove_control('bar_inner_typography_popover_toggle');
            $element->remove_control('bar_inner_typography_font_family');
            $element->remove_responsive_control('bar_inner_typography_font_size');
            $element->remove_control('bar_inner_typography_font_weight');
            $element->remove_control('bar_inner_typography_text_transform');
            $element->remove_control('bar_inner_typography_font_style');
            $element->remove_control('bar_inner_typography_text_decoration');
            $element->remove_responsive_control('bar_inner_typography_line_height');
            $element->remove_responsive_control('bar_inner_typography_letter_spacing');
            $element->remove_responsive_control('bar_inner_typography_word_spacing');

            $element->remove_control('bar_inner_shadow_text_shadow');
            $element->remove_control('bar_inner_shadow_text_shadow_type');

            $element->add_control(
                'progress_bar_bg_color',
                [
                    'label'     => esc_html__( 'Track Color', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .elementor-progress-wrapper' => 'background-color: {{VALUE}};',
                    ],
                ]
            );
            $element->add_control(
                'progress_bar_color',
                [
                    'label'     => esc_html__( 'Progress Color', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .elementor-progress-wrapper .elementor-progress-bar' => 'background-color: {{VALUE}};',
                    ],
                ]
            );
        }
        if ('progress' === $element->get_name() && 'section_title' === $section_id) {
            $element->remove_control('title_color');

            $element->remove_control('typography_typography');
            $element->remove_control('typography_popover_toggle');
            $element->remove_control('typography_font_family');
            $element->remove_responsive_control('typography_font_size');
            $element->remove_control('typography_font_weight');
            $element->remove_control('typography_text_transform');
            $element->remove_control('typography_font_style');
            $element->remove_control('typography_text_decoration');
            $element->remove_responsive_control('typography_line_height');
            $element->remove_responsive_control('typography_letter_spacing');
            $element->remove_responsive_control('typography_word_spacing');

            $element->remove_control('title_shadow_text_shadow');
            $element->remove_control('title_shadow_text_shadow_type');

            $element->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name'          => 'progress_title_typography',
                    'label'         => esc_html__('Title Typography', 'technum_plugin'),
                    'selector'      => '{{WRAPPER}} .elementor-widget-container .elementor-widget-progress .elementor-title'
                ]
            );
            $element->add_control(
                'progress_title_color',
                [
                    'label'     => esc_html__( 'Title Color', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .elementor-widget-container .elementor-widget-progress .elementor-title' => 'color: {{VALUE}};',
                    ]
                ]
            );

            $element->add_control(
                'progress_percentage_separator',
                [
                    'type'      => \Elementor\Controls_Manager::DIVIDER,
                    'condition' => [
                        'display_percentage'    => 'show'
                    ]
                ]
            );

            $element->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name'      => 'progress_percentage_typography',
                    'label'     => esc_html__('Percentage Typography', 'technum_plugin'),
                    'selector'  => '{{WRAPPER}} .elementor-widget-container .elementor-progress-percentage',
                    'condition' => [
                        'display_percentage'    => 'show'
                    ]
                ]
            );
            $element->add_control(
                'progress_percentage_color',
                [
                    'label'     => esc_html__( 'Percentage Color', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .elementor-widget-container .elementor-progress-percentage' => 'color: {{VALUE}};',
                    ],
                    'condition' => [
                        'display_percentage'    => 'show'
                    ]
                ]
            );
        }

        if ('counter' === $element->get_name() && 'section_counter' === $section_id) {
            $element->add_responsive_control(
                'info_align',
                [
                    'label'     => esc_html__('Text Alignment', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::CHOOSE,
                    'options'   => [
                        'left'      => [
                            'title'     => esc_html__('Left', 'technum_plugin'),
                            'icon'      => 'eicon-text-align-left',
                        ],
                        'center'    => [
                            'title'     => esc_html__('Center', 'technum_plugin'),
                            'icon'      => 'eicon-text-align-center',
                        ],
                        'right'     => [
                            'title'     => esc_html__('Right', 'technum_plugin'),
                            'icon'      => 'eicon-text-align-right',
                        ]
                    ],
                    'default'   => 'center',
                    'selectors' => [
                        '{{WRAPPER}} .elementor-counter .elementor-counter-title, {{WRAPPER}} .elementor-counter .elementor-counter-number-wrapper' => 'text-align: {{VALUE}};',
                    ],
                ]
            );
        }
        if ('counter' === $element->get_name() && 'section_number' === $section_id) {
            $element->remove_control('number_color');
            $element->add_control(
                'number_color',
                [
                    'label'     => esc_html__('Text Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .elementor-counter-number-wrapper' => '-webkit-text-stroke: 1px {{VALUE}};'
                    ]
                ]
            );
        }

        if ('icon' === $element->get_name() && 'section_icon' === $section_id) {
            $element->add_control(
                'add_pulse_animation',
                [
                    'label'         => esc_html__( 'Permanent Pulse Animation', 'technum_plugin' ),
                    'type'          => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'      => esc_html__( 'Show', 'technum_plugin' ),
                    'label_off'     => esc_html__( 'Hide', 'technum_plugin' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                    'prefix_class'  => 'pulse-animation-',
                    'toggle'        => true
                ]
            );
        }
        if ('icon' === $element->get_name() && 'section_style_icon' === $section_id) {
            $element->add_control(
                'pulse_border_color',
                [
                    'label'     => esc_html__('Pulse Animation Border Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .elementor-icon:before' => 'border-color: {{VALUE}};'
                    ],
                    'condition' => [
                        'add_pulse_animation'  => 'yes'
                    ],
                    'default'   => '#ffffff',
                    'separator' => 'before'
                ]
            );
        }

        if ( 'video' === $element->get_name() && 'section_image_overlay' === $section_id ) {
            $element->add_control(
                'show_color_overlay',
                [
                    'label'                 => esc_html__( 'Color Overlay', 'technum_plugin' ),
                    'type'                  => \Elementor\Controls_Manager::SWITCHER,
                    'label_off'             => esc_html__( 'Hide', 'technum_plugin' ),
                    'label_on'              => esc_html__( 'Show', 'technum_plugin' ),
                    'frontend_available'    => true,
                    'condition'             => [
                        'show_image_overlay'    => 'yes'
                    ],
                    'separator'             => 'before'
                ]
            );

            $element->start_controls_tabs(
                'tabs_background_overlay',
                [
                    'condition' => [
                        'show_image_overlay'    => 'yes',
                        'show_color_overlay'    => 'yes'
                    ],
                ]
            );

                $element->start_controls_tab(
                    'tab_background_overlay_normal',
                    [
                        'label' => esc_html__( 'Normal', 'technum_plugin' ),
                    ]
                );

                    $element->add_group_control(
                        \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'      => 'background_overlay',
                            'selector'  => '{{WRAPPER}} .elementor-custom-embed-image-overlay:before',
                        ]
                    );

                    $element->add_control(
                        'background_overlay_opacity',
                        [
                            'label'     => esc_html__( 'Opacity', 'technum_plugin' ),
                            'type'      => \Elementor\Controls_Manager::SLIDER,
                            'default'   => [
                                'size'      => .5,
                            ],
                            'range'     => [
                                'px'        => [
                                    'max'       => 1,
                                    'step'      => 0.01,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .elementor-custom-embed-image-overlay:before' => 'opacity: {{SIZE}};',
                            ],
                            'condition' => [
                                'background_overlay_background' => [ 'classic', 'gradient' ],
                            ],
                        ]
                    );

                    $element->add_group_control(
                        \Elementor\Group_Control_Css_Filter::get_type(),
                        [
                            'name'          => 'bg_css_filters',
                            'selector'      => '{{WRAPPER}} .elementor-custom-embed-image-overlay:before',
                            'conditions'    => [
                                'relation'      => 'or',
                                'terms'         => [
                                    [
                                        'name'      => 'background_overlay_image[url]',
                                        'operator'  => '!==',
                                        'value'     => '',
                                    ],
                                    [
                                        'name'      => 'background_overlay_color',
                                        'operator'  => '!==',
                                        'value'     => '',
                                    ],
                                ],
                            ],
                        ]
                    );

                    $element->add_control(
                        'overlay_blend_mode',
                        [
                            'label'         => esc_html__( 'Blend Mode', 'technum_plugin' ),
                            'type'          => \Elementor\Controls_Manager::SELECT,
                            'options'       => [
                                ''              => esc_html__( 'Normal', 'technum_plugin' ),
                                'multiply'      => 'Multiply',
                                'screen'        => 'Screen',
                                'overlay'       => 'Overlay',
                                'darken'        => 'Darken',
                                'lighten'       => 'Lighten',
                                'color-dodge'   => 'Color Dodge',
                                'saturation'    => 'Saturation',
                                'color'         => 'Color',
                                'luminosity'    => 'Luminosity',
                            ],
                            'selectors'     => [
                                '{{WRAPPER}} .elementor-custom-embed-image-overlay:before' => 'mix-blend-mode: {{VALUE}}',
                            ],
                            'conditions'    => [
                                'relation'      => 'or',
                                'terms'         => [
                                    [
                                        'name'      => 'background_overlay_image[url]',
                                        'operator'  => '!==',
                                        'value'     => '',
                                    ],
                                    [
                                        'name'      => 'background_overlay_color',
                                        'operator'  => '!==',
                                        'value'     => '',
                                    ],
                                ],
                            ],
                        ]
                    );

                $element->end_controls_tab();

                $element->start_controls_tab(
                    'tab_background_overlay_hover',
                    [
                        'label' => esc_html__( 'Hover', 'technum_plugin' ),
                    ]
                );

                    $element->add_group_control(
                        \Elementor\Group_Control_Background::get_type(),
                        [
                            'name'      => 'background_overlay_hover',
                            'selector'  => '{{WRAPPER}}:hover .elementor-custom-embed-image-overlay:before',
                        ]
                    );

                    $element->add_control(
                        'background_overlay_hover_opacity',
                        [
                            'label'     => esc_html__( 'Opacity', 'technum_plugin' ),
                            'type'      => \Elementor\Controls_Manager::SLIDER,
                            'default'   => [
                                'size'      => .5,
                            ],
                            'range'     => [
                                'px'        => [
                                    'max'       => 1,
                                    'step'      => 0.01,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}}:hover .elementor-custom-image-color-overlay:before' => 'opacity: {{SIZE}};',
                            ],
                            'condition' => [
                                'background_overlay_hover_background' => [ 'classic', 'gradient' ],
                            ],
                        ]
                    );

                    $element->add_group_control(
                        \Elementor\Group_Control_Css_Filter::get_type(),
                        [
                            'name'      => 'bg_css_filters_hover',
                            'selector'  => '{{WRAPPER}}:hover .elementor-custom-embed-image-overlay:before',
                        ]
                    );

                    $element->add_control(
                        'background_overlay_hover_transition',
                        [
                            'label'         => esc_html__( 'Transition Duration', 'technum_plugin' ),
                            'type'          => \Elementor\Controls_Manager::SLIDER,
                            'default'       => [
                                'size'  => 0.3,
                            ],
                            'range'         => [
                                'px'    => [
                                    'max'       => 3,
                                    'step'      => 0.1,
                                ],
                            ],
                            'render_type'   => 'ui',
                            'separator'     => 'before',
                        ]
                    );

                $element->end_controls_tab();

            $element->end_controls_tabs();
        }
        if ( 'video' === $element->get_name() && 'section_video_style' === $section_id ) {
            $element->remove_control('play_icon_title');
            $element->remove_control('play_icon_color');
            $element->remove_responsive_control('play_icon_size');
            $element->remove_control('play_icon_text_shadow');
            $element->remove_control('play_icon_text_shadow_type');

            $element->add_responsive_control(
                'video_width',
                [
                    'label'         => esc_html__('Video Max Width', 'technum_plugin'),
                    'type'          => \Elementor\Controls_Manager::SLIDER,
                    'size_units'    => [ 'px', '%' ],
                    'range'         => [
                        'px'            => [
                            'min'           => 100,
                            'max'           => 1170,
                        ],
                        '%'             => [
                            'min'           => 1,
                            'max'           => 100,
                        ]
                    ],
                    'selectors'     => [
                        '{{WRAPPER}} .elementor-widget-container' => 'max-width: {{SIZE}}{{UNIT}};'
                    ]
                ]
            );
            $element->add_responsive_control(
                'video_float',
                [
                    'label'     => esc_html__('Video Position', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::CHOOSE,
                    'options'   => [
                        'left'      => [
                            'title'     => esc_html__('Left', 'technum_plugin'),
                            'icon'      => 'eicon-text-align-left',
                        ],
                        'none'      => [
                            'title'     => esc_html__('Center', 'technum_plugin'),
                            'icon'      => 'eicon-text-align-center',
                        ],
                        'right'     => [
                            'title'     => esc_html__('Right', 'technum_plugin'),
                            'icon'      => 'eicon-text-align-right',
                        ]
                    ],
                    'default'   => 'left',
                    'selectors' => [
                        '{{WRAPPER}} .elementor-widget-container' => 'float: {{VALUE}};',
                    ],
                ]
            );
            $element->add_control(
                'play_icon_title',
                [
                    'label'     => esc_html__( 'Play Icon', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::HEADING,
                    'condition' => [
                        'show_image_overlay'    => 'yes',
                        'show_play_icon'        => 'yes',
                    ],
                    'separator' => 'before',
                ]
            );

            $element->add_responsive_control(
                'play_button_size',
                [
                    'label'     => esc_html__( 'Button Size', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::SLIDER,
                    'range'     => [
                        'px'        => [
                            'min'       => 10,
                            'max'       => 300,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .elementor-custom-embed-play'              => 'width: calc({{SIZE}}{{UNIT}} + 50px); height: calc({{SIZE}}{{UNIT}} + 50px);',
                        '{{WRAPPER}} .elementor-custom-embed-play:before'       => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}; margin: calc(-{{SIZE}}{{UNIT}} / 2) 0 0 calc(-{{SIZE}}{{UNIT}} / 2)',
                        '{{WRAPPER}} .elementor-custom-embed-play .progress'    => 'width: calc({{SIZE}}{{UNIT}} + 32px); height: calc({{SIZE}}{{UNIT}} + 32px); top: calc( 50% - ( ({{SIZE}}{{UNIT}} + 32px) / 2 )); left: calc( 50% - ( ({{SIZE}}{{UNIT}} + 32px) / 2 ));',
                    ],
                    'condition' => [
                        'show_image_overlay'    => 'yes',
                        'show_play_icon'        => 'yes',
                    ],
                ]
            );

            $element->add_responsive_control(
                'play_icon_size',
                [
                    'label'     => esc_html__( 'Icon Size', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::SLIDER,
                    'range'     => [
                        'px'        => [
                            'min'       => 10,
                            'max'       => 300,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .elementor-custom-embed-play:before' => 'font-size: {{SIZE}}{{UNIT}}',
                    ],
                    'condition' => [
                        'show_image_overlay'    => 'yes',
                        'show_play_icon'        => 'yes',
                    ],
                ]
            );

            $element->start_controls_tabs('button_settings_tabs');

                // ------------------------ //
                // ------ Normal Tab ------ //
                // ------------------------ //
                $element->start_controls_tab(
                    'tab_button_normal',
                    [
                        'label' => esc_html__('Normal', 'technum_plugin')
                    ]
                );

                    $element->add_control(
                        'play_icon_color',
                        [
                            'label'     => esc_html__('Icon Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .elementor-custom-embed-play:before' => 'color: {{VALUE}};'
                            ]
                        ]
                    );

                    $element->add_control(
                        'play_icon_bg',
                        [
                            'label'     => esc_html__('Icon Background', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .elementor-custom-embed-play:before' => 'background: {{VALUE}};',
                                '{{WRAPPER}} .elementor-custom-embed-play .progress__circle, {{WRAPPER}} .elementor-custom-embed-play .progress__path' => 'stroke: {{VALUE}};'
                            ]
                        ]
                    );

                $element->end_controls_tab();

                // ----------------------- //
                // ------ Hover Tab ------ //
                // ----------------------- //
                $element->start_controls_tab(
                    'tab_button_hover',
                    [
                        'label' => esc_html__('Hover', 'technum_plugin')
                    ]
                );

                    $element->add_control(
                        'play_icon_hover',
                        [
                            'label'     => esc_html__('Icon Hover', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .elementor-custom-embed-play:hover:before' => 'color: {{VALUE}};'
                            ]
                        ]
                    );

                    $element->add_control(
                        'play_icon_bg_hover',
                        [
                            'label'     => esc_html__('Icon Background Hover', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .elementor-custom-embed-play:hover:before' => 'background: {{VALUE}};',
                                '{{WRAPPER}} .elementor-custom-embed-play:hover .progress__circle, {{WRAPPER}} .elementor-custom-embed-play:hover .progress__path' => 'stroke: {{VALUE}};'
                            ]
                        ]
                    );

                $element->end_controls_tab();

            $element->end_controls_tabs();
        }

        if ('image-carousel' === $element->get_name() && 'section_style_navigation' === $section_id) {

            $element->remove_control('arrows_size');
            $element->remove_control('arrows_color');
            $element->remove_control('heading_style_dots');
            $element->remove_control('dots_position');
            $element->remove_control('dots_size');
            $element->remove_control('dots_color');



            $element->start_controls_tabs(
                'slider_nav_settings_tabs',
                [
                    'condition' => [
                        'navigation' => [ 'arrows', 'both' ],
                    ]
                ]
            );

            // ------------------------ //
            // ------ Normal Tab ------ //
            // ------------------------ //
            $element->start_controls_tab(
                'tab_arrows_normal',
                [
                    'label' => esc_html__('Normal', 'technum_plugin')
                ]
            );

            $element->add_control(
                'nav_color',
                [
                    'label'     => esc_html__('Slider Arrows Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container .elementor-swiper-button i' => 'color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_control(
                'nav_bd',
                [
                    'label'     => esc_html__('Slider Arrows Border', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container .elementor-swiper-button i' => 'border-color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_control(
                'nav_bg',
                [
                    'label'     => esc_html__('Slider Arrows Background', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container .elementor-swiper-button i' => 'background-color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name'      => 'nav_box_shadow',
                    'label'     => esc_html__( 'Box Shadow', 'technum_plugin' ),
                    'selector'  => '{{WRAPPER}} .swiper-container .elementor-swiper-button i',
                ]
            );

            $element->end_controls_tab();

            // ----------------------- //
            // ------ Hover Tab ------ //
            // ----------------------- //
            $element->start_controls_tab(
                'tab_arrows_hover',
                [
                    'label' => esc_html__('Hover', 'technum_plugin')
                ]
            );

            $element->add_control(
                'nav_hover',
                [
                    'label'     => esc_html__('Slider Arrows Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container .elementor-swiper-button:hover i' => 'color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_control(
                'nav_bd_hover',
                [
                    'label'     => esc_html__('Slider Arrows Border', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container .elementor-swiper-button:hover i' => 'border-color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_control(
                'nav_bg_hover',
                [
                    'label'     => esc_html__('Slider Arrows Background', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container .elementor-swiper-button:hover i' => 'background-color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name'      => 'nav_box_shadow_hover',
                    'label'     => esc_html__( 'Box Shadow', 'technum_plugin' ),
                    'selector'  => '{{WRAPPER}} .swiper-container .elementor-swiper-button:hover i',
                ]
            );

            $element->end_controls_tab();

            $element->end_controls_tabs();


            $element->add_control(
                'heading_style_dots',
                [
                    'label'     => esc_html__( 'Dots', 'elementor' ),
                    'type'      => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => [
                        'navigation' => [ 'dots', 'both' ],
                    ],
                ]
            );


            $element->start_controls_tabs(
                'slider_dot_settings_tabs',
                [
                    'condition' => [
                        'navigation' => [ 'dots', 'both' ],
                    ]
                ]
            );

            // ------------------------ //
            // ------ Normal Tab ------ //
            // ------------------------ //
            $element->start_controls_tab(
                'pagination_normal',
                [
                    'label' => esc_html__('Normal', 'technum_plugin')
                ]
            );

            $element->add_control(
                'dot_color',
                [
                    'label'     => esc_html__('Pagination Dot Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-pagination-bullet:after' => 'border-color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_control(
                'dot_border',
                [
                    'label'     => esc_html__('Pagination Dot Border', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-pagination-bullet' => 'border-color: {{VALUE}};'
                    ]
                ]
            );

            $element->end_controls_tab();

            // ------------------------ //
            // ------ Active Tab ------ //
            // ------------------------ //
            $element->start_controls_tab(
                'pagination_active',
                [
                    'label' => esc_html__('Active', 'technum_plugin')
                ]
            );

            $element->add_control(
                'dot_active',
                [
                    'label'     => esc_html__('Pagination Active Dot Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active:after' => 'border-color: {{VALUE}};'
                    ]
                ]
            );

            $element->add_control(
                'dot_border_active',
                [
                    'label'     => esc_html__('Pagination Active Dot Border', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};'
                    ]
                ]
            );

            $element->end_controls_tab();

            $element->end_controls_tabs();
        }
        if ('image-carousel' === $element->get_name() && 'section_style_image' === $section_id) {
            $element->remove_control('image_spacing');
            $element->remove_control('image_spacing_custom');
            $element->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name'      => 'image_shadow',
                    'selector'  => '{{WRAPPER}} .elementor-image-carousel-wrapper .elementor-image-carousel .swiper-slide-image',
                ]
            );

            $element->add_control(
                'image_spacing',
                [
                    'label'     => esc_html__( 'Spacing', 'technum_plugin' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
                        ''          => esc_html__( 'Default', 'technum_plugin' ),
                        'custom'    => esc_html__( 'Custom', 'technum_plugin' ),
                    ],
                    'default'   => '',
                    'condition' => [
                        'slides_to_show!' => '1',
                    ],
                ]
            );
            $element->add_control(
                'image_spacing_custom',
                [
                    'label'                 => esc_html__( 'Image Spacing', 'technum_plugin' ),
                    'type'                  => \Elementor\Controls_Manager::SLIDER,
                    'range'                 => [
                        'px'                    => [
                            'max'                   => 100,
                        ],
                    ],
                    'default'               => [
                        'size'                  => 20,
                    ],
                    'show_label'            => false,
                    'condition'             => [
                        'image_spacing'         => 'custom',
                        'slides_to_show!'       => '1',
                    ],
                    'frontend_available'    => true,
                    'render_type'           => 'none',
                    'separator'             => 'after',
                    'selectors'             => [
                        '{{WRAPPER}} .elementor-image-carousel-wrapper' => 'margin: -{{SIZE}}px; padding: {{SIZE}}px !important;'
                    ],
                ]
            );

            $element->add_control(
                'icon_color',
                [
                    'label'     => esc_html__('Icon Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-slide a:after' => 'color: {{VALUE}};'
                    ],
                    'separator' => 'before',
                    'condition' => [
                        'link_to'   => ['file', 'custom']
                    ]
                ]
            );

            $element->add_control(
                'icon_bg_color',
                [
                    'label'     => esc_html__('Icon Background Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-slide a:after' => 'background-color: {{VALUE}};'
                    ],
                    'condition' => [
                        'link_to'   => ['file', 'custom']
                    ]
                ]
            );

            $element->add_control(
                'overlay_color',
                [
                    'label'     => esc_html__('Image Overlay Color', 'technum_plugin'),
                    'type'      => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .swiper-slide a:before' => 'background-color: {{VALUE}};'
                    ],
                    'condition' => [
                        'link_to'       => ['file', 'custom'],
                        'view_style'    => 'style_2'
                    ]
                ]
            );


            $element->start_controls_tabs('frame_settings_tabs');

                // ------------------------ //
                // ------ Normal Tab ------ //
                // ------------------------ //
                $element->start_controls_tab(
                    'frame_normal',
                    [
                        'label'     => esc_html__('Normal', 'technum_plugin'),
                        'condition' => [
                            'link_to'    => ['file', 'custom'],
                            'view_style' => 'style_2'
                        ]
                    ]
                );

                    $element->add_control(
                        'frame_color',
                        [
                            'label'     => esc_html__('Frame Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .swiper-slide a:before' => 'border-color: {{VALUE}};'
                            ],
                            'condition' => [
                                'link_to'    => ['file', 'custom'],
                                'view_style' => 'style_2'
                            ]
                        ]
                    );

                $element->end_controls_tab();

                // ------------------------ //
                // ------ Active Tab ------ //
                // ------------------------ //
                $element->start_controls_tab(
                    'frame_hover',
                    [
                        'label'     => esc_html__('Hover', 'technum_plugin'),
                        'condition' => [
                            'link_to'    => ['file', 'custom'],
                            'view_style' => 'style_2'
                        ]
                    ]
                );

                    $element->add_control(
                        'frame_color_hover',
                        [
                            'label'     => esc_html__('Frame Color on Hover', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .swiper-slide a:hover:before' => 'border-color: {{VALUE}};'
                            ],
                            'condition' => [
                                'link_to'    => ['file', 'custom'],
                                'view_style' => 'style_2'
                            ]
                        ]
                    );

                $element->end_controls_tab();

            $element->end_controls_tabs();
        }

        if ('accordion' === $element->get_name() && 'section_title_style' === $section_id) {
            $element->remove_control('border_width');
            $element->remove_control('border_color');

            $element->add_responsive_control(
                'space_between',
                [
                    'label'     => esc_html__( 'Space Between', 'technum_plugin' ),
                    'type'      => \Elementor\Controls_Manager::SLIDER,
                    'range'     => [
                        'px'        => [
                            'min'       => 0,
                            'max'       => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .elementor-accordion-item:not(:last-of-type)' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                    ],
                ]
            );
            $element->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name'      => 'box_shadow',
                    'selector'  => '{{WRAPPER}} .elementor-accordion-item',
                ]
            );
        }
        if ('accordion' === $element->get_name() && 'section_toggle_style_title' === $section_id) {
            $element->remove_control('title_background');
            $element->remove_control('title_color');
            $element->remove_control('tab_active_color');

            $element->start_controls_tabs('title_colors_tabs');

                // ------------------------ //
                // ------ Normal Tab ------ //
                // ------------------------ //
                $element->start_controls_tab(
                    'title_colors_normal',
                    [
                        'label' => esc_html__('Normal', 'technum_plugin')
                    ]
                );

                    $element->add_control(
                        'title_color',
                        [
                            'label'     => esc_html__('Title Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title:not(.elementor-active) .elementor-accordion-title' => 'color: {{VALUE}};'
                            ]
                        ]
                    );

                    $element->add_control(
                        'title_bg_color',
                        [
                            'label'     => esc_html__('Title Background Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title:not(.elementor-active)' => 'background-color: {{VALUE}};'
                            ]
                        ]
                    );

                $element->end_controls_tab();

                // ------------------------ //
                // ------ Active Tab ------ //
                // ------------------------ //
                $element->start_controls_tab(
                    'title_colors_active',
                    [
                        'label' => esc_html__('Active', 'technum_plugin')
                    ]
                );

                    $element->add_control(
                        'active_title_color',
                        [
                            'label'     => esc_html__('Title Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title.elementor-active .elementor-accordion-title' => 'color: {{VALUE}};'
                            ]
                        ]
                    );

                    $element->add_control(
                        'active_title_bg_color',
                        [
                            'label'     => esc_html__('Title Background Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title.elementor-active' => 'background-color: {{VALUE}};'
                            ]
                        ]
                    );

                $element->end_controls_tab();

            $element->end_controls_tabs();
        }

        if ('toggle' === $element->get_name() && 'section_toggle_style' === $section_id) {
            $element->remove_control('border_width');
            $element->remove_control('border_color');
        }
        if ('toggle' === $element->get_name() && 'section_toggle_style_title' === $section_id) {
            $element->remove_control('title_background');
            $element->remove_control('title_color');
            $element->remove_control('tab_active_color');

            $element->start_controls_tabs('title_colors_tabs');

                // ------------------------ //
                // ------ Normal Tab ------ //
                // ------------------------ //
                $element->start_controls_tab(
                    'title_colors_normal',
                    [
                        'label' => esc_html__('Normal', 'technum_plugin')
                    ]
                );

                    $element->add_control(
                        'title_color',
                        [
                            'label'     => esc_html__('Title Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title:not(.elementor-active) .elementor-toggle-title' => 'color: {{VALUE}};'
                            ]
                        ]
                    );

                    $element->add_control(
                        'title_bg_color',
                        [
                            'label'     => esc_html__('Title Background Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title:not(.elementor-active)' => 'background-color: {{VALUE}};'
                            ]
                        ]
                    );

                $element->end_controls_tab();

                // ------------------------ //
                // ------ Active Tab ------ //
                // ------------------------ //
                $element->start_controls_tab(
                    'title_colors_active',
                    [
                        'label' => esc_html__('Active', 'technum_plugin')
                    ]
                );

                    $element->add_control(
                        'active_title_color',
                        [
                            'label'     => esc_html__('Title Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title.elementor-active .elementor-toggle-title' => 'color: {{VALUE}};'
                            ]
                        ]
                    );

                    $element->add_control(
                        'active_title_bg_color',
                        [
                            'label'     => esc_html__('Title Background Color', 'technum_plugin'),
                            'type'      => \Elementor\Controls_Manager::COLOR,
                            'default'   => '',
                            'selectors' => [
                                '{{WRAPPER}} .elementor-tab-title.elementor-active' => 'background-color: {{VALUE}};'
                            ]
                        ]
                    );

                $element->end_controls_tab();

            $element->end_controls_tabs();
        }

    }, 10, 3);

    add_action('elementor/widget/render_content', function( $content, $widget ) {
        if ( 'video' === $widget->get_name() ) {
            $content = str_replace('<i aria-hidden="true" class="eicon-play"></i>', '<svg aria-hidden="true" class="progress" width="70" height="70" viewBox="0 0 70 70"><path class="progress__circle" d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z"></path><path class="progress__path" d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z" pathLength="1"></path></svg>', $content);
            $content = str_replace('<i class="eicon-play" aria-hidden="true"></i>', '<svg aria-hidden="true" class="progress" width="70" height="70" viewBox="0 0 70 70"><path class="progress__circle" d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z"></path><path class="progress__path" d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z" pathLength="1"></path></svg>', $content);
        }

        return $content;
    }, 10, 2 );

    add_action('elementor/frontend/section/before_render', function( \Elementor\Element_Base $element ) {
        $settings = $element->get_settings();
        if ( $settings['use_parallax'] == 'yes' ) {
            $element->add_render_attribute('_wrapper', [
                'data-parallax'     => 'scroll'
            ] );
        }
    } );

}