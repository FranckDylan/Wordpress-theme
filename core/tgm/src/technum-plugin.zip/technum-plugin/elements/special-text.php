<?php

/*
 * Created by Artureanec
*/

namespace TechnUm\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class TechnUm_Special_Text_Widget extends Widget_Base {

    public function get_name() {
        return 'technum_special_text';
    }

    public function get_title() {
        return esc_html__('Special Text', 'technum_plugin');
    }

    public function get_icon() {
        return 'eicon-t-letter';
    }

    public function get_categories() {
        return ['technum_widgets'];
    }

    protected function register_controls() {

        // ----------------------------- //
        // ---------- Content ---------- //
        // ----------------------------- //
        $this->start_controls_section(
            'section_special_text',
            [
                'label' => esc_html__('Special Text', 'technum_plugin')
            ]
        );

        $this->add_control(
            'effect',
            [
                'label'     => esc_html__( 'Select Effect', 'technum_plugin' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'stroke',
                'options'   => [
                    'stroke'    => esc_html__( 'Stroke', 'technum_plugin' ),
                    'fill'      => esc_html__( 'Fill', 'technum_plugin' )
                ],
            ]
        );

        $this->add_control(
            'text',
            [
                'label'         => esc_html__( 'Text', 'technum_plugin' ),
                'type'          => Controls_Manager::WYSIWYG
            ]
        );

        $this->add_control(
            'text_tag',
            [
                'label'     => esc_html__('HTML Tag', 'technum_plugin'),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'h1'        => esc_html__( 'H1', 'technum_plugin' ),
                    'h2'        => esc_html__( 'H2', 'technum_plugin' ),
                    'h3'        => esc_html__( 'H3', 'technum_plugin' ),
                    'h4'        => esc_html__( 'H4', 'technum_plugin' ),
                    'h5'        => esc_html__( 'H5', 'technum_plugin' ),
                    'h6'        => esc_html__( 'H6', 'technum_plugin' ),
                    'div'       => esc_html__( 'div', 'technum_plugin' ),
                    'span'      => esc_html__( 'span', 'technum_plugin' ),
                    'p'         => esc_html__( 'p', 'technum_plugin' )
                ],
                'default'   => 'div'
            ]
        );

        $this->add_responsive_control(
            'text_align',
            [
                'label'     => esc_html__('Alignment', 'technum_plugin'),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'left'      => [
                        'title'     => esc_html__('Left', 'technum_plugin'),
                        'icon'      => 'eicon-text-align-left',
                    ],
                    'center'    => [
                        'title'     => esc_html__('Center', 'technum_plugin'),
                        'icon'      => 'eicon-text-align-center',
                    ],
                    'right'     => [
                        'title'     => esc_html__('Right', 'technum_plugin'),
                        'icon'      => 'eicon-text-align-right',
                    ]
                ],
                'default'   => 'left',
                'selectors' => [
                    '{{WRAPPER}} .special-text' => 'text-align: {{VALUE}};',
                ],
                'separator' => 'before'
            ]
        );

        $this->end_controls_section();

        // ----------------------------------- //
        // ---------- Text Settings ---------- //
        // ----------------------------------- //
        $this->start_controls_section(
            'section_text_settings',
            [
                'label' => esc_html__('Text Settings', 'technum_plugin'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'text_typography',
                'label'     => esc_html__('Text Typography', 'technum_plugin'),
                'selector'  => '{{WRAPPER}} .special-text'
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'     => esc_html__('Text Stroke Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .special-text' => '-webkit-text-stroke: 1px {{VALUE}}; text-stroke: 1px {{VALUE}};'
                ],
                'condition' => [
                    'effect'    => 'stroke'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'text_background',
                'label'     => esc_html__( 'Text Background', 'plugin-domain' ),
                'types'     => [ 'classic', 'gradient' ],
                'selector'  => '{{WRAPPER}} .special-text',
                'condition' => [
                    'effect'    => 'fill'
                ]
            ]
        );

        $this->add_control(
            'text_opacity',
            [
                'label'     => esc_html__('Opacity', 'technum_plugin'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    '%'         => [
                        'min'       => 0,
                        'max'       => 1,
                        'step'      => .01
                    ]
                ],
                'default'   => [
                    'unit'      => '%',
                    'size'      => 0.3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .special-text' => 'opacity: {{SIZE}};'
                ]
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings       = $this->get_settings();
        $effect         = $settings['effect'];
        $text           = $settings['text'];
        $text_tag       = $settings['text_tag'];

        $block_classes  = 'special-text special-text-effect-' . ( !empty($effect) ? esc_attr($effect) : 'stroke' );

        // ------------------------------------ //
        // ---------- Widget Content ---------- //
        // ------------------------------------ //
        if ( !empty($text) ) {
            echo '<' . esc_html($text_tag) . ' class="' . esc_attr($block_classes) . '">';
                echo wp_kses($text, array(
                    'br'        => array(),
                    'span'      => array(
                        'style'     => true
                    ),
                    'a'         => array(
                        'href'      => true,
                        'target'    => true
                    ),
                    'img'       => array(
                        'src'       => true,
                        'srcset'    => true,
                        'sizes'     => true,
                        'class'     => true,
                        'alt'       => true,
                        'title'     => true
                    ),
                    'em'        => array(),
                    'strong'    => array(),
                    'del'       => array()
                ));
            echo '</' . esc_html($text_tag) . '>';
        }
    }

    protected function content_template() {}

    public function render_plain_content() {}
}
