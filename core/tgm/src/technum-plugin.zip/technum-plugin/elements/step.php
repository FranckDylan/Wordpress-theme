<?php
/*
 * Created by Artureanec
*/

namespace TechnUm\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\REPEATER;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class TechnUm_Step_Widget extends Widget_Base {

    public function get_name() {
        return 'technum_step';
    }

    public function get_title() {
        return esc_html__('Step', 'technum_plugin');
    }

    public function get_icon() {
        return 'eicon-editor-list-ol';
    }

    public function get_categories() {
        return ['technum_widgets'];
    }

    protected function register_controls() {

        // ----------------------------- //
        // ---------- Content ---------- //
        // ----------------------------- //
        $this->start_controls_section(
            'section_content',
            [
                'label'         => esc_html__('Step', 'technum_plugin')
            ]
        );

        $this->add_control(
            'view_style',
            [
                'label'     => esc_html__( 'Style', 'technum_plugin' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'standard',
                'options'   => [
                    'standard'  => esc_html__( 'Standard', 'technum_plugin' ),
                    'extended'  => esc_html__( 'Extended', 'technum_plugin' )
                ],
            ]
        );

        $this->add_control(
            'step_image',
            [
                'label'     => esc_html__('Image', 'technum_plugin'),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url'           => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'view_style'    => 'extended'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'step_image_thumbnail',
                'default'   => 'custom'
            ]
        );

        $this->add_control(
            'step_number',
            [
                'label'     => esc_html__('Step Number', 'technum_plugin'),
                'type'      => Controls_Manager::TEXT,
                'default'   => '01',
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'step_title',
            [
                'label'         => esc_html__('Title', 'technum_plugin'),
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => ''
            ]
        );

        $this->add_control(
            'step_description',
            [
                'label'         => esc_html__('Description', 'technum_plugin'),
                'description'   => esc_html__('Enter description', 'technum_plugin'),
                'type'          => Controls_Manager::TEXTAREA,
                'default'       => ''
            ]
        );

        $this->add_responsive_control(
            'step_align',
            [
                'label'     => esc_html__('Alignment', 'technum_plugin'),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'left'      => [
                        'title'     => esc_html__('Left', 'technum_plugin'),
                        'icon'      => 'eicon-text-align-left',
                    ],
                    'center'    => [
                        'title'     => esc_html__('Center', 'technum_plugin'),
                        'icon'      => 'eicon-text-align-center',
                    ],
                    'right'     => [
                        'title'     => esc_html__('Right', 'technum_plugin'),
                        'icon'      => 'eicon-text-align-right',
                    ]
                ],
                'default'   => 'left',
                'selectors' => [
                    '{{WRAPPER}} .step-item' => 'text-align: {{VALUE}};',
                ],
                'separator' => 'before'
            ]
        );

        $this->end_controls_section();

        // ----------------------------------- //
        // ---------- Item Settings ---------- //
        // ----------------------------------- //
        $this->start_controls_section(
            'section_item_settings',
            [
                'label'         => esc_html__('Step Item Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'view_style'    => 'standard'
                ]
            ]
        );

        $this->add_control(
            'item_background_color',
            [
                'label'         => esc_html__('Background Color', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-standard' => 'background-color: {{VALUE}};'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'          => 'item_shadow',
                'label'         => esc_html__('Item Shadow', 'technum_plugin'),
                'selector'      => '{{WRAPPER}} .step-item.step-item-type-standard'
            ]
        );

        $this->add_control(
            'item_padding',
            [
                'label'         => esc_html__('Item Padding', 'technum_plugin'),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => ['px', 'em', '%'],
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-standard' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'          => 'bg_number_typography',
                'label'         => esc_html__('Background Number Typography', 'technum_plugin'),
                'selector'      => '{{WRAPPER}} .step-item.step-item-type-standard .step-bg-number',
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'bg_number_color',
            [
                'label'         => esc_html__('Background Number Color', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-standard .step-bg-number' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->end_controls_section();

        // ------------------------------------- //
        // ---------- Number Settings ---------- //
        // ------------------------------------- //
        $this->start_controls_section(
            'section_number_settings',
            [
                'label'         => esc_html__('Number Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'view_style'    => 'standard'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'          => 'number_typography',
                'label'         => esc_html__('Number Typography', 'technum_plugin'),
                'selector'      => '{{WRAPPER}} .step-item.step-item-type-standard .step-number'
            ]
        );

        $this->add_control(
            'number_color',
            [
                'label'         => esc_html__('Number Color', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-standard .step-number' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'number_spacing',
            [
                'label'         => esc_html__('Space between number and title', 'technum_plugin'),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'            => [
                        'min' => 0,
                        'max' => 200
                    ]
                ],
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-standard .step-number:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->end_controls_section();

        // ------------------------------------ //
        // ---------- Image Settings ---------- //
        // ------------------------------------ //
        $this->start_controls_section(
            'section_image_settings',
            [
                'label'         => esc_html__('Image Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'view_style'    => 'extended'
                ]
            ]
        );

        $this->add_control(
            'image_overlay_color',
            [
                'label'         => esc_html__('Image Overlay Color', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-extended .step-image  .step-image-box:after' => 'background-image: linear-gradient(0deg, {{VALUE}} 0%, {{VALUE}} 10%, transparent 68%);'
                ]
            ]
        );

        $this->add_control(
            'image_frame_color',
            [
                'label'         => esc_html__('Image Frame Color', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-extended .step-image:before' => 'border-color: {{VALUE}};'
                ]
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => esc_html__('Tabs Title Area Radius', 'technum_plugin'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .step-item.step-item-type-extended .step-image img, {{WRAPPER}} .step-item.step-item-type-extended .step-image:before, {{WRAPPER}} .step-item.step-item-type-extended .step-image:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'          => 'image_number_typography',
                'label'         => esc_html__('Number Typography', 'technum_plugin'),
                'selector'      => '{{WRAPPER}} .step-item.step-item-type-extended .step-image .step-number',
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'image_number_color',
            [
                'label'         => esc_html__('Number Color', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-extended .step-image .step-number' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'image_spacing',
            [
                'label'         => esc_html__('Space between image and content', 'technum_plugin'),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'            => [
                        'min'           => 0,
                        'max'           => 200
                    ]
                ],
                'selectors'     => [
                    '{{WRAPPER}} .step-item.step-item-type-extended .step-image:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};'
                ],
                'separator'     => 'before'
            ]
        );

        $this->end_controls_section();

        // ------------------------------------ //
        // ---------- Title Settings ---------- //
        // ------------------------------------ //
        $this->start_controls_section(
            'section_title_settings',
            [
                'label'         => esc_html__('Title Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'          => 'title_typography',
                'label'         => esc_html__('Title Typography', 'technum_plugin'),
                'selector'      => '{{WRAPPER}} .step-title'
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'         => esc_html__('Title Color', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-title' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->add_control(
            'title_hover',
            [
                'label'         => esc_html__('Title Hover', 'technum_plugin'),
                'type'          => Controls_Manager::COLOR,
                'default'       => '',
                'selectors'     => [
                    '{{WRAPPER}} .step-item:hover .step-title' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label'         => esc_html__('Space between title and description', 'technum_plugin'),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'            => [
                        'min' => 0,
                        'max' => 200
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .step-title:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->end_controls_section();

        // ------------------------------------------ //
        // ---------- Description Settings ---------- //
        // ------------------------------------------ //
        $this->start_controls_section(
            'section_description_settings',
            [
                'label' => esc_html__('Description Settings', 'technum_plugin'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'description_typography',
                'label'     => esc_html__('Description Typography', 'technum_plugin'),
                'selector'  => '{{WRAPPER}} .step-description'
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label'     => esc_html__('Description Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .step-description' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings           = $this->get_settings();

        $view_style         = $settings['view_style'];
        $step_number        = $settings['step_number'];
        $step_title         = $settings['step_title'];
        $step_description   = $settings['step_description'];

        // ------------------------------------ //
        // ---------- Widget Content ---------- //
        // ------------------------------------ //
        ?>

        <div class="technum-step-widget">
            <div class="step-item step-item-type-<?php echo esc_attr($view_style); ?>">

                <?php
                    if ( !empty($step_number) && $view_style == 'extended' ) {
                        echo '<div class="step-image">';
                            echo '<div class="step-image-box">';
                                echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'step_image_thumbnail', 'step_image' );
                            echo '</div>';
                            echo '<div class="step-number"><div class="step-number-inner">' . esc_html($step_number) . '</div></div>';
                        echo '</div>';
                    }
                    if ( !empty($step_number) && $view_style == 'standard' ) {
                        echo '<div class="step-bg-number">' . esc_html($step_number) . '</div>';
                        echo '<div class="step-number">' . esc_html($step_number) . '</div>';
                    }
                    if ( !empty($step_title) ) {
                        echo '<h4 class="step-title">' . esc_html($step_title) . '</h4>';
                    }
                    if ( !empty($step_description) ) {
                        echo '<div class="step-description">' . esc_html($step_description) . '</div>';
                    }
                ?>

            </div>
        </div>
        <?php
    }

    protected function content_template() {}

    public function render_plain_content() {}
}
