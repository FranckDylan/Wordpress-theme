<?php
/*
 * Created by Artureanec
*/

namespace TechnUm\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\REPEATER;
use Elementor\Utils;
use Elementor\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class TechnUm_Content_Slider_Widget extends Widget_Base {

    public function get_name() {
        return 'technum_content_slider';
    }

    public function get_title() {
        return esc_html__('Content Slider', 'technum_plugin');
    }

    public function get_icon() {
        return 'eicon-post-slider';
    }

    public function get_categories() {
        return ['technum_widgets'];
    }

    public function get_script_depends() {
        return ['elementor_widgets'];
    }

    protected function register_controls() {

        // ----------------------------- //
        // ---------- Content ---------- //
        // ----------------------------- //
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Slider', 'technum_plugin')
            ]
        );

        $this->add_responsive_control(
            'slider_height',
            [
                'label'     => esc_html__('Slider Height', 'technum_plugin'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px'        => [
                        'min'       => 10,
                        'max'       => 2000,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-item' => 'height: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_control(
            'add_socials',
            [
                'label'         => esc_html__('Show social buttons', 'technum_plugin'),
                'type'          => Controls_Manager::SWITCHER,
                'label_off'     => esc_html__('No', 'technum_plugin'),
                'label_on'      => esc_html__('Yes', 'technum_plugin'),
                'return_value'  => 'yes',
                'default'       => 'no',
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'add_contacts',
            [
                'label'         => esc_html__('Show contact info', 'technum_plugin'),
                'type'          => Controls_Manager::SWITCHER,
                'label_off'     => esc_html__('No', 'technum_plugin'),
                'label_on'      => esc_html__('Yes', 'technum_plugin'),
                'return_value'  => 'yes',
                'default'       => 'no',
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'contact_email_title',
            [
                'label'         => esc_html__('Email title', 'technum_plugin'),
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => '',
                'condition'     => [
                    'add_contacts'  => 'yes'
                ]
            ]
        );

        $this->add_control(
            'contact_email_text',
            [
                'label'         => esc_html__('Email text', 'technum_plugin'),
                'type'          => Controls_Manager::WYSIWYG,
                'label_block'   => true,
                'placeholder'   => esc_html__('Enter text', 'technum_plugin'),
                'default'       => '',
                'condition'     => [
                    'add_contacts'  => 'yes'
                ]
            ]
        );

        $this->add_control(
            'contact_phone_title',
            [
                'label'         => esc_html__('Phone title', 'technum_plugin'),
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => '',
                'condition'     => [
                    'add_contacts'  => 'yes'
                ],
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'contact_phone_text',
            [
                'label'         => esc_html__('Phone text', 'technum_plugin'),
                'type'          => Controls_Manager::WYSIWYG,
                'label_block'   => true,
                'placeholder'   => esc_html__('Enter text', 'technum_plugin'),
                'default'       => '',
                'condition'     => [
                    'add_contacts'  => 'yes'
                ]
            ]
        );

        $this->add_control(
            'contact_address_title',
            [
                'label'         => esc_html__('Address title', 'technum_plugin'),
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => '',
                'condition'     => [
                    'add_contacts'  => 'yes'
                ],
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'contact_address_text',
            [
                'label'         => esc_html__('Address text', 'technum_plugin'),
                'type'          => Controls_Manager::WYSIWYG,
                'label_block'   => true,
                'placeholder'   => esc_html__('Enter text', 'technum_plugin'),
                'default'       => '',
                'condition'     => [
                    'add_contacts'  => 'yes'
                ]
            ]
        );

        $this->add_control(
            'add_video',
            [
                'label'         => esc_html__('Show video preview', 'technum_plugin'),
                'type'          => Controls_Manager::SWITCHER,
                'label_off'     => esc_html__('No', 'technum_plugin'),
                'label_on'      => esc_html__('Yes', 'technum_plugin'),
                'return_value'  => 'yes',
                'default'       => 'no',
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'video_type',
            [
                'label'     => esc_html__( 'Source', 'technum_plugin' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'youtube',
                'options'   => [
                    'youtube'       => esc_html__( 'YouTube', 'technum_plugin' ),
                    'vimeo'         => esc_html__( 'Vimeo', 'technum_plugin' ),
                    'dailymotion'   => esc_html__( 'Dailymotion', 'technum_plugin' ),
                    'hosted'        => esc_html__( 'Self Hosted', 'technum_plugin' )
                ],
                'frontend_available' => true,
                'condition' => [
                    'add_video'     => 'yes'
                ]
            ]
        );

        $this->add_control(
            'youtube_url',
            [
                'label'         => esc_html__( 'Link', 'technum_plugin' ),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => [
                    'active'        => true,
                    'categories'    => [
                        TagsModule::POST_META_CATEGORY,
                        TagsModule::URL_CATEGORY
                    ]
                ],
                'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ) . ' (YouTube)',
                'default'       => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
                'label_block'   => true,
                'condition'     => [
                    'add_video'     => 'yes',
                    'video_type'    => 'youtube'
                ],
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'vimeo_url',
            [
                'label'         => esc_html__( 'Link', 'technum_plugin' ),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => [
                    'active'        => true,
                    'categories'    => [
                        TagsModule::POST_META_CATEGORY,
                        TagsModule::URL_CATEGORY
                    ],
                ],
                'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ) . ' (Vimeo)',
                'default'       => 'https://vimeo.com/235215203',
                'label_block'   => true,
                'condition'     => [
                    'add_video'     => 'yes',
                    'video_type'    => 'vimeo'
                ]
            ]
        );

        $this->add_control(
            'dailymotion_url',
            [
                'label'         => esc_html__( 'Link', 'technum_plugin' ),
                'type'          => Controls_Manager::TEXT,
                'dynamic'       => [
                    'active'        => true,
                    'categories'    => [
                        TagsModule::POST_META_CATEGORY,
                        TagsModule::URL_CATEGORY
                    ],
                ],
                'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ) . ' (Dailymotion)',
                'default'       => 'https://www.dailymotion.com/video/x6tqhqb',
                'label_block'   => true,
                'condition'     => [
                    'add_video'     => 'yes',
                    'video_type'    => 'dailymotion'
                ]
            ]
        );

        $this->add_control(
            'insert_url',
            [
                'label'     => esc_html__( 'External URL', 'technum_plugin' ),
                'type'      => Controls_Manager::SWITCHER,
                'condition' => [
                    'add_video'     => 'yes',
                    'video_type'    => 'hosted'
                ]
            ]
        );

        $this->add_control(
            'hosted_url',
            [
                'label'         => esc_html__( 'Choose File', 'technum_plugin' ),
                'type'          => Controls_Manager::MEDIA,
                'dynamic'       => [
                    'active'        => true,
                    'categories'    => [
                        TagsModule::MEDIA_CATEGORY
                    ],
                ],
                'media_type'    => 'video',
                'condition'     => [
                    'add_video'     => 'yes',
                    'video_type'    => 'hosted',
                    'insert_url'    => ''
                ]
            ]
        );

        $this->add_control(
            'external_url',
            [
                'label'         => esc_html__( 'URL', 'technum_plugin' ),
                'type'          => Controls_Manager::URL,
                'autocomplete'  => false,
                'options'       => false,
                'label_block'   => true,
                'show_label'    => false,
                'dynamic'       => [
                    'active'        => true,
                    'categories'    => [
                        TagsModule::POST_META_CATEGORY,
                        TagsModule::URL_CATEGORY
                    ]
                ],
                'media_type'    => 'video',
                'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ),
                'condition'     => [
                    'add_video'     => 'yes',
                    'video_type'    => 'hosted',
                    'insert_url'    => 'yes'
                ],
            ]
        );

        $this->add_control(
            'image_overlay',
            [
                'label'                 => esc_html__( 'Image Overlay', 'technum_plugin' ),
                'type'                  => Controls_Manager::MEDIA,
                'dynamic'               => [
                    'active'                => true,
                ],
                'condition'             => [
                    'add_video'             => 'yes'
                ],
                'frontend_available'    => true
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'image_overlay',
                'default'   => 'thumbnail',
                'separator' => 'none',
                'condition' => [
                    'add_video' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();


        // ---------------------------- //
        // ---------- Slider ---------- //
        // ---------------------------- //
        $this->start_controls_section(
            'section_slider',
            [
                'label' => esc_html__('Slider Settings', 'technum_plugin')
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'slide_name',
            [
                'label'     => esc_html__('Slide Name', 'technum_plugin'),
                'type'      => Controls_Manager::TEXT,
                'default'   => '',
                'separator' => 'after'
            ]
        );

        $repeater->add_responsive_control(
            'content_max_width',
            [
                'label'         => esc_html__('Text Column Width, %', 'technum_plugin'),
                'type'          => Controls_Manager::SLIDER,
                'size_units'    => ['%'],
                'range'         => [
                    '%'             => [
                        'min' => 1,
                        'max' => 100
                    ]
                ],
                'selectors'     => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .slide-content-column'    => 'width: {{SIZE}}%;'
                ]
            ]
        );

        $repeater->add_control(
            'content_position',
            [
                'label'         => esc_html__('Text Column Position', 'technum_plugin'),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'start'         => [
                        'title'         => esc_html__( 'Left', 'technum_plugin' ),
                        'icon'          => 'eicon-h-align-left'
                    ],
                    'center'        => [
                        'title'         => esc_html__( 'Center', 'technum_plugin' ),
                        'icon'          => 'eicon-h-align-center'
                    ],
                    'end'           => [
                        'title'         => esc_html__( 'Right', 'technum_plugin' ),
                        'icon'          => 'eicon-h-align-right'
                    ]
                ]
            ]
        );

        $repeater->add_responsive_control(
            'content_text_align',
            [
                'label'     => esc_html__('Text Alignment', 'technum_plugin'),
                'type'      => Controls_Manager::CHOOSE,
                'default'   => 'center',
                'options'   => [
                    'left'      => [
                        'title'     => esc_html__( 'Left', 'technum_plugin' ),
                        'icon'      => 'eicon-text-align-left'
                    ],
                    'center'    => [
                        'title'     => esc_html__( 'Center', 'technum_plugin' ),
                        'icon'      => 'eicon-text-align-center'
                    ],
                    'right'     => [
                        'title'     => esc_html__( 'Right', 'technum_plugin' ),
                        'icon'      => 'eicon-text-align-right'
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .slide-content-column' => 'text-align: {{VALUE}};'
                ]
            ]
        );

        $repeater->add_control(
            'divider_1',
            [
                'type' => Controls_Manager::DIVIDER
            ]
        );




        $repeater->start_controls_tabs('button_settings_tabs');

        // -------------------- //
        // ------ BG Tab ------ //
        // -------------------- //
        $repeater->start_controls_tab(
            'tab_bg',
            [
                'label' => esc_html__('BG', 'technum_plugin')
            ]
        );

            $repeater->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name'      => 'background',
                    'label'     => esc_html__( 'Background', 'technum_plugin' ),
                    'types'     => [ 'classic', 'gradient' ],
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}}'
                ]
            );

            $repeater->add_control(
                'add_bg_overlay',
                [
                    'label'         => esc_html__('Add Overlay', 'technum_plugin'),
                    'type'          => Controls_Manager::SWITCHER,
                    'default'       => 'no',
                    'return_value'  => 'yes',
                    'label_off'     => esc_html__('No', 'technum_plugin'),
                    'label_on'      => esc_html__('Yes', 'technum_plugin'),
                    'separator'     => 'before'
                ]
            );

            $repeater->add_control(
                'bg_overlay_color',
                [
                    'label'     => esc_html__('Overlay Color', 'technum_plugin'),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}}' => 'background-color: {{VALUE}};'
                    ],
                    'condition' => [
                        'add_bg_overlay'    => 'yes'
                    ]
                ]
            );

        $repeater->end_controls_tab();

        // ----------------------- //
        // ------ Image Tab ------ //
        // ----------------------- //
        $repeater->start_controls_tab(
            'tab_image',
            [
                'label' => esc_html__('Image', 'technum_plugin')
            ]
        );

            $repeater->add_control(
                'additional_image',
                [
                    'label' => esc_html__('Additional Image', 'technum_plugin'),
                    'type' => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ]
                ]
            );

            $repeater->add_responsive_control(
                'image_max_width',
                [
                    'label'         => esc_html__('Image Column Width, %', 'technum_plugin'),
                    'type'          => Controls_Manager::SLIDER,
                    'size_units'    => ['%'],
                    'range'         => [
                        '%'             => [
                            'min' => 1,
                            'max' => 100
                        ]
                    ],
                    'selectors'     => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .slide-image-column'    => 'width: {{SIZE}}%;'
                    ]
                ]
            );

            $repeater->add_responsive_control(
                'additional_image_align',
                [
                    'label'     => esc_html__('Image Alignment', 'technum_plugin'),
                    'type'      => Controls_Manager::CHOOSE,
                    'default'   => 'right',
                    'options'   => [
                        'left'      => [
                            'title'     => esc_html__( 'Left', 'technum_plugin' ),
                            'icon'      => 'eicon-text-align-left'
                        ],
                        'center'    => [
                            'title'     => esc_html__( 'Center', 'technum_plugin' ),
                            'icon'      => 'eicon-text-align-center'
                        ],
                        'right'     => [
                            'title'     => esc_html__( 'Right', 'technum_plugin' ),
                            'icon'      => 'eicon-text-align-right'
                        ]
                    ],
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .additional-image' => 'text-align: {{VALUE}};'
                    ]
                ]
            );

            $repeater->add_control(
                'additional_image_vertical_position',
                [
                    'label'     => esc_html__('Vertical Position', 'technum_plugin'),
                    'type'      => Controls_Manager::CHOOSE,
                    'default'   => 'middle',
                    'options'   => [
                        'top'       => [
                            'title'     => esc_html__( 'Top', 'technum_plugin' ),
                            'icon'      => 'eicon-v-align-top'
                        ],
                        'middle'    => [
                            'title'     => esc_html__( 'Middle', 'technum_plugin' ),
                            'icon'      => 'eicon-v-align-middle'
                        ],
                        'bottom'    => [
                            'title'     => esc_html__( 'Bottom', 'technum_plugin' ),
                            'icon'      => 'eicon-v-align-bottom'
                        ]
                    ]
                ]
            );

            $repeater->add_responsive_control(
                'image_margin',
                [
                    'label' => esc_html__('Position', 'technum_plugin'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['%', 'px'],
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .additional-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                    ]
                ]
            );

        $repeater->end_controls_tab();

        // ----------------------- //
        // ------ Title Tab ------ //
        // ----------------------- //
        $repeater->start_controls_tab(
            'tab_title',
            [
                'label' => esc_html__('Title', 'technum_plugin')
            ]
        );

            $repeater->add_control(
                'heading',
                [
                    'label'         => esc_html__('Title', 'technum_plugin'),
                    'type'          => Controls_Manager::WYSIWYG,
                    'label_block'   => true,
                    'placeholder'   => esc_html__('Enter Title', 'technum_plugin'),
                    'default'       => esc_html__('Title', 'technum_plugin')
                ]
            );

            $repeater->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'heading_typography',
                    'label'     => esc_html__('Heading Typography', 'technum_plugin'),
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .technum-heading .technum-heading-content'
                ]
            );

            $repeater->add_control(
                'heading_color',
                [
                    'label'     => esc_html__('Heading Color', 'technum_plugin'),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .technum-heading .technum-heading-content' => 'color: {{VALUE}};'
                    ]
                ]
            );

            $repeater->add_control(
                'accent_text_color',
                [
                    'label'     => esc_html__('Text Underline Color', 'technum_plugin'),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} .technum-heading .technum-heading-content span[style *= "text-decoration: underline"]:before' => 'background-color: {{VALUE}} !important;'
                    ]
                ]
            );

            $repeater->add_group_control(
                Group_Control_Text_Shadow::get_type(),
                [
                    'name'      => 'title_shadow',
                    'label'     => esc_html__('Heading Text Shadow', 'technum_plugin'),
                    'selector'  => '{{WRAPPER}} .technum-heading .technum-heading-content'
                ]
            );

            $repeater->add_control(
                'add_subtitle',
                [
                    'label'         => esc_html__('Add Subtitle', 'technum_plugin'),
                    'type'          => Controls_Manager::SWITCHER,
                    'default'       => 'no',
                    'return_value'  => 'yes',
                    'label_off'     => esc_html__('No', 'technum_plugin'),
                    'label_on'      => esc_html__('Yes', 'technum_plugin'),
                    'separator'     => 'before'
                ]
            );

            $repeater->add_control(
                'subtitle',
                [
                    'label'         => esc_html__('Subtitle', 'technum_plugin'),
                    'type'          => Controls_Manager::TEXT,
                    'default'       => '',
                    'placeholder'   => esc_html__( 'Enter Your Subtitle', 'technum_plugin'),
                    'label_block'   => true,
                    'condition'     => [
                        'add_subtitle'  => 'yes'
                    ]
                ]
            );

            $repeater->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'subtitle_typography',
                    'label'     => esc_html__('Subheading Typography', 'technum_plugin'),
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .technum-subheading',
                    'condition' => [
                        'add_subtitle'  => 'yes'
                    ]
                ]
            );

            $repeater->add_control(
                'subtitle_color',
                [
                    'label'     => esc_html__('Subheading Color', 'technum_plugin'),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .technum-subheading' => '-webkit-text-stroke: 1px {{VALUE}};'
                    ],
                    'condition' => [
                        'add_subtitle'  => 'yes'
                    ]
                ]
            );

        $repeater->end_controls_tab();

        // ---------------------- //
        // ------ Text Tab ------ //
        // ---------------------- //
        $repeater->start_controls_tab(
            'tab_text',
            [
                'label' => esc_html__('Text', 'technum_plugin')
            ]
        );

            $repeater->add_control(
                'text',
                [
                    'label'         => esc_html__('Promo Text', 'technum_plugin'),
                    'type'          => Controls_Manager::WYSIWYG,
                    'default'       => '',
                    'placeholder'   => esc_html__('Enter Promo Text', 'technum_plugin'),
                    'separator'     => 'before'
                ]
            );

            $repeater->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name'      => 'text_typography',
                    'label'     => esc_html__('Text Typography', 'technum_plugin'),
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .content-slider-item-text'
                ]
            );

            $repeater->add_control(
                'text_color',
                [
                    'label'     => esc_html__('Text Color', 'technum_plugin'),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '',
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .content-slider-item-text' => 'color: {{VALUE}};'
                    ]
                ]
            );

        $repeater->end_controls_tab();

            // ------------------------- //
            // ------ Buttons Tab ------ //
            // ------------------------- //
            $repeater->start_controls_tab(
                'tab_button',
                [
                    'label' => esc_html__('Buttons', 'technum_plugin')
                ]
            );

                $repeater->add_control(
                    'button_text',
                    [
                        'label'     => esc_html__('Button Text', 'technum_plugin'),
                        'type'      => Controls_Manager::TEXT,
                        'default'   => esc_html__('Button', 'technum_plugin'),
                        'separator' => 'before'
                    ]
                );

                $repeater->add_control(
                    'button_link',
                    [
                        'label'         => esc_html__('Button Link', 'technum_plugin'),
                        'type'          => Controls_Manager::URL,
                        'label_block'   => true,
                        'default'       => [
                            'url'           => '',
                            'is_external'   => 'true',
                        ],
                        'placeholder'   => esc_html__( 'http://your-link.com', 'technum_plugin' )
                    ]
                );

                $repeater->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'      => 'button_typography',
                        'label'     => esc_html__('Button Typography', 'technum_plugin'),
                        'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .technum-button'
                    ]
                );

                $repeater->add_control(
                    'button_color',
                    [
                        'label'     => esc_html__('Button Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-button' => 'color: {{VALUE}};'
                        ],
                        'separator' => 'before'
                    ]
                );

                $repeater->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name'      => 'button_bg',
                        'label'     => esc_html__( 'Button Background', 'technum_plugin' ),
                        'types'     => [ 'classic', 'gradient' ],
                        'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .technum-button:after'
                    ]
                );

                $repeater->add_control(
                    'button_color_hover',
                    [
                        'label'     => esc_html__('Button Hover Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-button:hover' => 'color: {{VALUE}};'
                        ],
                        'separator' => 'before'
                    ]
                );

                $repeater->add_control(
                    'button_radius',
                    [
                        'label'         => esc_html__('Border Radius', 'technum_plugin'),
                        'type'          => Controls_Manager::DIMENSIONS,
                        'size_units'    => ['px', '%'],
                        'selectors'     => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                        ],
                        'separator'     => 'before'
                    ]
                );

                $repeater->add_control(
                    'button_padding',
                    [
                        'label'         => esc_html__('Button Padding', 'technum_plugin'),
                        'type'          => Controls_Manager::DIMENSIONS,
                        'size_units'    => ['px', '%'],
                        'selectors'     => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                        ]
                    ]
                );

                $repeater->add_control(
                    'add_video_button',
                    [
                        'label'         => esc_html__('Add Video Button', 'technum_plugin'),
                        'type'          => Controls_Manager::SWITCHER,
                        'default'       => 'no',
                        'return_value'  => 'yes',
                        'label_off'     => esc_html__('No', 'technum_plugin'),
                        'label_on'      => esc_html__('Yes', 'technum_plugin'),
                        'separator'     => 'before'
                    ]
                );

                $repeater->add_control(
                    'slide_video_button_type',
                    [
                        'label'     => esc_html__( 'Button type', 'technum_plugin' ),
                        'type'      => Controls_Manager::SELECT,
                        'default'   => 'type_1',
                        'options'   => [
                            'type_1'    => esc_html__( 'Type 1', 'technum_plugin' ),
                            'type_2'    => esc_html__( 'Type 2', 'technum_plugin' )
                        ],
                        'condition' => [
                            'add_video_button'  => 'yes'
                        ]
                    ]
                );

                $repeater->add_control(
                    'video_button_text',
                    [
                        'label'     => esc_html__('Button Text', 'technum_plugin'),
                        'type'      => Controls_Manager::TEXT,
                        'default'   => esc_html__('Button', 'technum_plugin'),
                        'separator' => 'before',
                        'condition' => [
                            'add_video_button'  => 'yes'
                        ]
                    ]
                );

                $repeater->add_control(
                    'slide_video_type',
                    [
                        'label'     => esc_html__( 'Source', 'technum_plugin' ),
                        'type'      => Controls_Manager::SELECT,
                        'default'   => 'youtube',
                        'options'   => [
                            'youtube'       => esc_html__( 'YouTube', 'technum_plugin' ),
                            'vimeo'         => esc_html__( 'Vimeo', 'technum_plugin' ),
                            'dailymotion'   => esc_html__( 'Dailymotion', 'technum_plugin' ),
                            'hosted'        => esc_html__( 'Self Hosted', 'technum_plugin' )
                        ],
                        'frontend_available' => true,
                        'condition' => [
                            'add_video_button'  => 'yes'
                        ]
                    ]
                );

                $repeater->add_control(
                    'slide_youtube_url',
                    [
                        'label'         => esc_html__( 'Link', 'technum_plugin' ),
                        'type'          => Controls_Manager::TEXT,
                        'dynamic'       => [
                            'active'        => true,
                            'categories'    => [
                                TagsModule::POST_META_CATEGORY,
                                TagsModule::URL_CATEGORY
                            ]
                        ],
                        'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ) . ' (YouTube)',
                        'default'       => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
                        'label_block'   => true,
                        'condition'     => [
                            'add_video_button'  => 'yes',
                            'slide_video_type'  => 'youtube'
                        ],
                        'frontend_available' => true
                    ]
                );

                $repeater->add_control(
                    'slide_vimeo_url',
                    [
                        'label'         => esc_html__( 'Link', 'technum_plugin' ),
                        'type'          => Controls_Manager::TEXT,
                        'dynamic'       => [
                            'active'        => true,
                            'categories'    => [
                                TagsModule::POST_META_CATEGORY,
                                TagsModule::URL_CATEGORY
                            ],
                        ],
                        'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ) . ' (Vimeo)',
                        'default'       => 'https://vimeo.com/235215203',
                        'label_block'   => true,
                        'condition'     => [
                            'add_video_button'  => 'yes',
                            'slide_video_type'  => 'vimeo'
                        ]
                    ]
                );

                $repeater->add_control(
                    'slide_dailymotion_url',
                    [
                        'label'         => esc_html__( 'Link', 'technum_plugin' ),
                        'type'          => Controls_Manager::TEXT,
                        'dynamic'       => [
                            'active'        => true,
                            'categories'    => [
                                TagsModule::POST_META_CATEGORY,
                                TagsModule::URL_CATEGORY
                            ],
                        ],
                        'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ) . ' (Dailymotion)',
                        'default'       => 'https://www.dailymotion.com/video/x6tqhqb',
                        'label_block'   => true,
                        'condition'     => [
                            'add_video_button'  => 'yes',
                            'slide_video_type'  => 'dailymotion'
                        ]
                    ]
                );

                $repeater->add_control(
                    'slide_insert_url',
                    [
                        'label'     => esc_html__( 'External URL', 'technum_plugin' ),
                        'type'      => Controls_Manager::SWITCHER,
                        'condition' => [
                            'add_video_button'  => 'yes',
                            'slide_video_type'  => 'hosted'
                        ]
                    ]
                );

                $repeater->add_control(
                    'slide_hosted_url',
                    [
                        'label'         => esc_html__( 'Choose File', 'technum_plugin' ),
                        'type'          => Controls_Manager::MEDIA,
                        'dynamic'       => [
                            'active'        => true,
                            'categories'    => [
                                TagsModule::MEDIA_CATEGORY
                            ],
                        ],
                        'media_type'    => 'video',
                        'condition'     => [
                            'add_video_button'  => 'yes',
                            'slide_video_type'  => 'hosted',
                            'slide_insert_url'  => ''
                        ]
                    ]
                );

                $repeater->add_control(
                    'slide_external_url',
                    [
                        'label'         => esc_html__( 'URL', 'technum_plugin' ),
                        'type'          => Controls_Manager::URL,
                        'autocomplete'  => false,
                        'options'       => false,
                        'label_block'   => true,
                        'show_label'    => false,
                        'dynamic'       => [
                            'active'        => true,
                            'categories'    => [
                                TagsModule::POST_META_CATEGORY,
                                TagsModule::URL_CATEGORY
                            ]
                        ],
                        'media_type'    => 'video',
                        'placeholder'   => esc_html__( 'Enter your URL', 'technum_plugin' ),
                        'condition'     => [
                            'add_video_button'  => 'yes',
                            'slide_video_type'  => 'hosted',
                            'slide_insert_url'  => 'yes'
                        ]
                    ]
                );

                $repeater->add_control(
                    'video_button_color',
                    [
                        'label'     => esc_html__('Video Button Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-video-button' => 'color: {{VALUE}};'
                        ],
                        'separator' => 'before',
                        'condition' => [
                            'add_video_button'  => 'yes'
                        ]
                    ]
                );

                $repeater->add_control(
                    'video_button_bg_color',
                    [
                        'label'     => esc_html__('Video Button Background Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-video-button' => 'background-color: {{VALUE}};'
                        ],
                        'condition' => [
                            'add_video_button'  => 'yes'
                        ]
                    ]
                );

                $repeater->add_control(
                    'video_button_hover',
                    [
                        'label'     => esc_html__('Video Button Hover', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-video-button:hover' => 'color: {{VALUE}};'
                        ],
                        'separator' => 'before',
                        'condition' => [
                            'add_video_button'  => 'yes'
                        ]
                    ]
                );

                $repeater->add_control(
                    'video_button_bg_hover',
                    [
                        'label'     => esc_html__('Video Button Background Hover', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} {{CURRENT_ITEM}} .technum-video-button:hover' => 'background-color: {{VALUE}};'
                        ],
                        'condition' => [
                            'add_video_button'  => 'yes'
                        ]
                    ]
                );

            $repeater->end_controls_tab();

        $repeater->end_controls_tabs();

        $this->add_control(
            'content_items',
            [
                'label'         => esc_html__('Slides', 'technum_plugin'),
                'type'          => Controls_Manager::REPEATER,
                'fields'        => $repeater->get_controls(),
                'title_field'   => '{{{slide_name}}}',
                'prevent_empty' => true,
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'nav',
            [
                'label'         => esc_html__('Show navigation buttons', 'technum_plugin'),
                'type'          => Controls_Manager::SWITCHER,
                'label_off'     => esc_html__('No', 'technum_plugin'),
                'label_on'      => esc_html__('Yes', 'technum_plugin'),
                'return_value'  => 'yes',
                'default'       => 'no',
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'dots',
            [
                'label'         => esc_html__('Show pagination dots', 'technum_plugin'),
                'type'          => Controls_Manager::SWITCHER,
                'label_off'     => esc_html__('No', 'technum_plugin'),
                'label_on'      => esc_html__('Yes', 'technum_plugin'),
                'return_value'  => 'yes',
                'default'       => 'yes',
                'separator'     => 'before'
            ]
        );

        $this->add_control(
            'dots_position',
            [
                'label'     => esc_html__( 'Pagination position', 'technum_plugin' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'bottom',
                'options'   => [
                    'bottom'    => esc_html__( 'Bottom', 'technum_plugin' ),
                    'left'      => esc_html__( 'Left', 'technum_plugin' ),
                    'right'     => esc_html__( 'Right', 'technum_plugin' )
                ],
                'condition' => [
                    'dots'      => 'yes'
                ]
            ]
        );

        $this->add_control(
            'dots_v_align',
            [
                'label'     => esc_html__( 'Pagination alignment', 'technum_plugin' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'middle',
                'options'   => [
                    'top'           => esc_html__( 'Top', 'technum_plugin' ),
                    'middle'        => esc_html__( 'Middle', 'technum_plugin' ),
                    'bottom'         => esc_html__( 'Bottom', 'technum_plugin' )
                ],
                'condition' => [
                    'dots'              => 'yes',
                    'dots_position!'    => 'bottom'
                ]
            ]
        );

        $this->add_control(
            'speed',
            [
                'label'     => esc_html__('Animation Speed', 'technum_plugin'),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 1200,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'infinite',
            [
                'label'     => esc_html__('Infinite Loop', 'technum_plugin'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'yes',
                'options'   => [
                    'yes'       => esc_html__('Yes', 'technum_plugin'),
                    'no'        => esc_html__('No', 'technum_plugin'),
                ],
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label'     => esc_html__('Autoplay', 'technum_plugin'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'yes',
                'options'   => [
                    'yes'       => esc_html__('Yes', 'technum_plugin'),
                    'no'        => esc_html__('No', 'technum_plugin'),
                ],
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label'     => esc_html__('Autoplay Speed', 'technum_plugin'),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 5000,
                'condition' => [
                    'autoplay'  => 'yes'
                ]
            ]
        );

        $this->add_control(
            'autoplay_timeout',
            [
                'label'     => esc_html__('Autoplay Timeout', 'technum_plugin'),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 5000,
                'step'      => 100,
                'condition' => [
                    'autoplay'  => 'yes'
                ]
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => esc_html__('Pause on Hover', 'technum_plugin'),
                'type' => Controls_Manager::SELECT,
                'default' => 'yes',
                'options' => [
                    'yes' => esc_html__('Yes', 'technum_plugin'),
                    'no' => esc_html__('No', 'technum_plugin'),
                ],
                'condition' => [
                    'autoplay' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();


        // --------------------------------------- //
        // ---------- Contacts Settings ---------- //
        // --------------------------------------- //
        $this->start_controls_section(
            'section_contacts_settings',
            [
                'label'         => esc_html__('Contacts Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'add_contacts'  => 'yes'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'contacts_title_typography',
                'label'     => esc_html__('Title Typography', 'technum_plugin'),
                'selector'  => '{{WRAPPER}} .bottom-area .contacts .contact-item-title'
            ]
        );

        $this->add_control(
            'contacts_title_color',
            [
                'label'     => esc_html__('Title Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .bottom-area .contacts .contact-item-title' => 'color: {{VALUE}};'
                ],
                'separator' => 'after'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'contacts_text_typography',
                'label'     => esc_html__('Text Typography', 'technum_plugin'),
                'selector'  => '{{WRAPPER}} .bottom-area .contacts .contact-item-text'
            ]
        );

        $this->add_control(
            'contacts_text_color',
            [
                'label'     => esc_html__('Text Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .bottom-area .contacts .contact-item-text, {{WRAPPER}} .bottom-area .contacts .contact-item-text a' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->add_control(
            'contacts_text_accent',
            [
                'label'     => esc_html__('Accent Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .bottom-area .contacts .contact-item-text a:hover, {{WRAPPER}} .bottom-area .contacts .contact-item:before' => 'color: {{VALUE}};'
                ],
                'separator' => 'after'
            ]
        );

        $this->add_control(
            'contacts_bg_color',
            [
                'label'     => esc_html__('Contacts Background', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .bottom-area .contacts' => 'background-color: {{VALUE}};'
                ]
            ]
        );

        $this->end_controls_section();


        // -------------------------------------------- //
        // ---------- Video Preview Settings ---------- //
        // -------------------------------------------- //
        $this->start_controls_section(
            'section_video_settings',
            [
                'label'         => esc_html__('Video Preview Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'add_video'     => 'yes'
                ]
            ]
        );

        $this->add_control(
            'video_play_bg',
            [
                'label'     => esc_html__('Play Button Background', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .bottom-area .content-slider-video .elementor-custom-embed-play .eicon-play' => 'background-color: {{VALUE}};'
                ]
            ]
        );

        $this->add_control(
            'video_play_icon',
            [
                'label'     => esc_html__('Play Icon Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .bottom-area .content-slider-video .elementor-custom-embed-play .eicon-play:before' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->end_controls_section();


        // --------------------------------------------- //
        // ---------- Social Buttons Settings ---------- //
        // --------------------------------------------- //
        $this->start_controls_section(
            'section_socials_settings',
            [
                'label'         => esc_html__('Social Buttons Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE,
                'condition'     => [
                    'add_socials'     => 'yes'
                ]
            ]
        );

        $this->start_controls_tabs('social_icon_tabs');

            // ------------------------ //
            // ------ Normal Tab ------ //
            // ------------------------ //
            $this->start_controls_tab(
                'social_icon_normal',
                [
                    'label' => esc_html__('Normal', 'technum_plugin')
                ]
            );

                $this->add_control(
                    'socials_icon_color',
                    [
                        'label'     => esc_html__('Icon Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .content-slider-socials a' => 'color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'socials_bg_color',
                    [
                        'label'     => esc_html__('Icon Background Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .content-slider-socials a' => 'background-color: {{VALUE}};'
                        ]
                    ]
                );

            $this->end_controls_tab();

            // ----------------------- //
            // ------ Hover Tab ------ //
            // ----------------------- //
            $this->start_controls_tab(
                'social_icon_hover',
                [
                    'label' => esc_html__('Hover', 'technum_plugin')
                ]
            );

                $this->add_control(
                    'socials_hover',
                    [
                        'label'     => esc_html__('Hovered Icon Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .content-slider-socials a:hover' => 'color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'socials_bg_hover',
                    [
                        'label'     => esc_html__('Hovered Icon Background Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .content-slider-socials a:hover' => 'background-color: {{VALUE}};'
                        ]
                    ]
                );

            $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        // ----------------------------------------- //
        // ---------- Slider Nav Settings ---------- //
        // ----------------------------------------- //
        $this->start_controls_section(
            'section_slider_settings',
            [
                'label'         => esc_html__('Slider Navigation Settings', 'technum_plugin'),
                'tab'           => Controls_Manager::TAB_STYLE,
                'conditions'    => [
                    'relation'  => 'or',
                    'terms'     => [
                        [
                            'name'      => 'dots',
                            'operator'  => '==',
                            'value'     => 'yes'
                        ],
                        [
                            'name'      => 'nav',
                            'operator'  => '==',
                            'value'     => 'yes'
                        ]
                    ]
                ]
            ]
        );

        $this->add_control(
            'dot_separator_color',
            [
                'label'     => esc_html__('Dots Separator Border Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .aside-area' => 'border-color: {{VALUE}};'
                ],
                'condition' => [
                    'dots'          => 'yes',
                    'dots_position' => [ 'left', 'right' ]
                ]
            ]
        );

        $this->add_control(
            'pagination_title',
            [
                'label' => esc_html__( 'Slider Pagination', 'technum_plugin' ),
                'type'  => Controls_Manager::HEADING
            ]
        );

        $this->start_controls_tabs(
            'slider_pagination_settings_tabs',
            [
                'condition' => [
                    'dots'      => 'yes'
                ]
            ]
        );

            // ------------------------ //
            // ------ Normal Tab ------ //
            // ------------------------ //
            $this->start_controls_tab(
                'slider_dots_normal',
                [
                    'label' => esc_html__('Normal', 'technum_plugin')
                ]
            );

                $this->add_control(
                    'dot_color',
                    [
                        'label'     => esc_html__('Pagination Dot Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-dots .owl-dot span:after' => 'border-color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'dot_border',
                    [
                        'label'     => esc_html__('Pagination Dot Border', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-dots .owl-dot span' => 'border-color: {{VALUE}};'
                        ]
                    ]
                );

            $this->end_controls_tab();

            // ------------------------ //
            // ------ Active Tab ------ //
            // ------------------------ //
            $this->start_controls_tab(
                'slider_dots_active',
                [
                    'label' => esc_html__('Active', 'technum_plugin')
                ]
            );

                $this->add_control(
                    'dot_active',
                    [
                        'label'     => esc_html__('Pagination Active Dot Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-dots .owl-dot.active span:after' => 'border-color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'dot_border_active',
                    [
                        'label'     => esc_html__('Pagination Active Dot Border', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-dots .owl-dot.active span' => 'border-color: {{VALUE}};'
                        ]
                    ]
                );

            $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'separator_arrows',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'arrows_title',
            [
                'label' => esc_html__( 'Slider Navigation', 'technum_plugin' ),
                'type'  => Controls_Manager::HEADING
            ]
        );

        $this->start_controls_tabs(
            'slider_nav_settings_tabs',
            [
                'condition' => [
                    'nav'       => 'yes'
                ]
            ]
        );

            // ------------------------ //
            // ------ Normal Tab ------ //
            // ------------------------ //
            $this->start_controls_tab(
                'tab_arrows_normal',
                [
                    'label' => esc_html__('Normal', 'technum_plugin')
                ]
            );

                $this->add_control(
                    'nav_color',
                    [
                        'label'     => esc_html__('Slider Arrows Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]:before' => 'color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'nav_bd',
                    [
                        'label'     => esc_html__('Slider Arrows Border', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]' => 'border-color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'nav_bg',
                    [
                        'label'     => esc_html__('Slider Arrows Background', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]' => 'background-color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name'      => 'nav_box_shadow',
                        'label'     => esc_html__( 'Box Shadow', 'technum_plugin' ),
                        'selector'  => '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]',
                    ]
                );

            $this->end_controls_tab();

            // ----------------------- //
            // ------ Hover Tab ------ //
            // ----------------------- //
            $this->start_controls_tab(
                'tab_arrows_hover',
                [
                    'label' => esc_html__('Hover', 'technum_plugin')
                ]
            );

                $this->add_control(
                    'nav_hover',
                    [
                        'label'     => esc_html__('Slider Arrows Color', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]:not(.disabled):hover:before' => 'color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'nav_bd_hover',
                    [
                        'label'     => esc_html__('Slider Arrows Border', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]:not(.disabled):hover' => 'border-color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_control(
                    'nav_bg_hover',
                    [
                        'label'     => esc_html__('Slider Arrows Background', 'technum_plugin'),
                        'type'      => Controls_Manager::COLOR,
                        'default'   => '',
                        'selectors' => [
                            '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]:not(.disabled):hover' => 'background-color: {{VALUE}};'
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name'      => 'nav_box_shadow_hover',
                        'label'     => esc_html__( 'Box Shadow', 'technum_plugin' ),
                        'selector'  => '{{WRAPPER}} .owl-theme .owl-nav [class*="owl-"]:not(.disabled):hover',
                    ]
                );

            $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $settings               = $this->get_settings();

        $add_socials            = $settings['add_socials'];
        $add_contacts           = $settings['add_contacts'];
        $contact_email_title    = $settings['contact_email_title'];
        $contact_email_text     = $settings['contact_email_text'];
        $contact_phone_title    = $settings['contact_phone_title'];
        $contact_phone_text     = $settings['contact_phone_text'];
        $contact_address_title  = $settings['contact_address_title'];
        $contact_address_text   = $settings['contact_address_text'];

        $add_video              = $settings['add_video'];
        $video_type             = $settings['video_type'];
        $youtube_url            = $settings['youtube_url'];
        $vimeo_url              = $settings['vimeo_url'];
        $dailymotion_url        = $settings['dailymotion_url'];
        $insert_url             = $settings['insert_url'];
        $hosted_url             = $settings['hosted_url'];
        $external_url           = $settings['external_url'];

        $content_items          = $settings['content_items'];
        $widget_id              = $this->get_id();

        $slider_options         = [
            'items'                 => 1,
            'nav'                   => ('yes' === $settings['nav']),
            'dots'                  => ('yes' === $settings['dots']),
            'autoplayHoverPause'    => ('yes' === $settings['pause_on_hover']),
            'autoplay'              => ('yes' === $settings['autoplay']),
            'autoplaySpeed'         => absint($settings['autoplay_speed']),
            'autoplayTimeout'       => absint($settings['autoplay_timeout']),
            'loop'                  => ('yes' === $settings['infinite']),
            'speed'                 => absint($settings['speed']),
            'dotsContainer'         => !empty($widget_id) ? '.owl-dots-' . esc_attr($widget_id) : false,
            'animateOut'            => 'fadeOut'
        ];

        // ------------------------------------ //
        // ---------- Widget Content ---------- //
        // ------------------------------------ //
        ?>

        <div class="technum-content-slider-widget">
            <div class="content-slider-wrapper">

                <div class="content-slider-container">
                    <div class="content-slider owl-carousel owl-theme" data-slider-options="<?php echo esc_attr(wp_json_encode($slider_options)); ?>">
                        <?php

                        foreach ($content_items as $slide) {
                            $item_classes = 'content-item slider-item';
                            $item_classes .= ' elementor-repeater-item-' . esc_attr($slide['_id']);
                            $item_classes .= ' content-position-' . esc_attr($slide['content_position']);
                            $item_classes .= ' image-vertical-position-' . esc_attr($slide['additional_image_vertical_position']);
                            $item_classes .= ' aside-area-position-' . ( !empty($settings['dots_position']) ? esc_attr($settings['dots_position']) : 'left' );

                            $add_video_button           = $slide['add_video_button'];
                            $slide_video_button_type    = $slide['slide_video_button_type'];
                            $video_button_text          = $slide['video_button_text'];
                            $slide_video_type           = $slide['slide_video_type'];
                            $slide_youtube_url          = $slide['slide_youtube_url'];
                            $slide_vimeo_url            = $slide['slide_vimeo_url'];
                            $slide_dailymotion_url      = $slide['slide_dailymotion_url'];
                            $slide_insert_url           = $slide['slide_insert_url'];
                            $slide_hosted_url           = $slide['slide_hosted_url'];
                            $slide_external_url         = $slide['slide_external_url'];

                            echo '<div class="' . esc_attr($item_classes) . '">';

                                echo '<div class="elementor-section elementor-section-boxed">';
                                    echo '<div class="elementor-container elementor-column-gap-extended">';
                                        echo '<div class="elementor-row">';

                                            echo '<div class="slide-content-column">';

                                                if ( !empty($slide['heading']) ) {
                                                    echo '<div class="technum-content-wrapper-1">';
                                                        echo '<div class="technum-heading content-slider-item-heading">';
                                                            if ( $slide['add_subtitle'] == 'yes' && !empty($slide['subtitle']) ) {
                                                                echo '<span class="technum-subheading">' . esc_html($slide['subtitle']) . '</span>';
                                                            }
                                                            echo '<span class="technum-heading-content">';
                                                                echo wp_kses($slide['heading'], array(
                                                                    'br'        => array(),
                                                                    'span'      => array(
                                                                        'style'     => true
                                                                    ),
                                                                    'a'         => array(
                                                                        'href'      => true,
                                                                        'target'    => true
                                                                    ),
                                                                    'img'       => array(
                                                                        'src'       => true,
                                                                        'srcset'    => true,
                                                                        'sizes'     => true,
                                                                        'class'     => true,
                                                                        'alt'       => true,
                                                                        'title'     => true
                                                                    ),
                                                                    'em'        => array(),
                                                                    'strong'    => array(),
                                                                    'del'       => array()
                                                                ));
                                                            echo '</span>';
                                                        echo '</div>';
                                                    echo '</div>';
                                                }

                                                if ( !empty($slide['text']) ) {
                                                    echo '<div class="technum-content-wrapper-2">';
                                                        echo '<div class="content-slider-item-text">' . wp_kses_post($slide['text']) . '</div>';
                                                    echo '</div>';
                                                }

                                                if (
                                                    !empty($slide['button_text']) ||
                                                    (
                                                        $add_video_button == 'yes' && (
                                                            ( $slide_video_type == 'youtube' && !empty($slide_youtube_url) ) ||
                                                            ( $slide_video_type == 'vimeo' && !empty($slide_vimeo_url) ) ||
                                                            ( $slide_video_type == 'dailymotion' && !empty($slide_dailymotion_url) ) ||
                                                            ( $slide_video_type == 'hosted' && (
                                                                !empty($slide_insert_url) ||
                                                                !empty($slide_hosted_url) ||
                                                                !empty($slide_external_url)
                                                            ) )
                                                        )
                                                    )
                                                ) {
                                                    echo '<div class="technum-content-wrapper-3">';
                                                        echo '<div class="content-slider-item-buttons">';

                                                            if ( !empty($slide['button_text']) ) {
                                                                if ( !empty($slide['button_link']['url']) ) {
                                                                    $button_url = $slide['button_link']['url'];
                                                                } else {
                                                                    $button_url = '#';
                                                                }
                                                                echo '<a class="technum-button" href="' . esc_url($button_url) . '"' . (($slide['button_link']['is_external'] == true) ? ' target="_blank"' : '') . (($slide['button_link']['nofollow'] == 'on') ? ' rel="nofollow"' : '') . '>';
                                                                    echo esc_html($slide['button_text']);
                                                                echo '</a>';
                                                            }

                                                            if (
                                                                $add_video_button == 'yes' && (
                                                                    ( $slide_video_type == 'youtube' && !empty($slide_youtube_url) ) ||
                                                                    ( $slide_video_type == 'vimeo' && !empty($slide_vimeo_url) ) ||
                                                                    ( $slide_video_type == 'dailymotion' && !empty($slide_dailymotion_url) ) ||
                                                                    ( $slide_video_type == 'hosted' && (
                                                                            !empty($slide_insert_url) ||
                                                                            !empty($slide_hosted_url) ||
                                                                            !empty($slide_external_url)
                                                                        ) )
                                                                )
                                                            ) {
                                                                    $slide_video_url = $slide[ 'slide_' . $slide_video_type . '_url' ];

                                                                    if ( 'hosted' === $slide_video_type ) {
                                                                        $slide_video_url = $this->get_hosted_video_url();
                                                                    } else {
                                                                        $slide_embed_params = $this->get_embed_params();
                                                                        $slide_embed_options = $this->get_embed_options();
                                                                    }

                                                                    if ( 'youtube' === $slide_video_type ) {
                                                                        $slide_video_html = '<div class="elementor-video"></div>';
                                                                    }

                                                                    if ( 'hosted' === $slide_video_type ) {
                                                                        $this->add_render_attribute( 'video-wrapper', 'class', 'e-hosted-video' );

                                                                        ob_start();

                                                                        $this->render_hosted_video();

                                                                        $slide_video_html = ob_get_clean();
                                                                    } else {
                                                                        $slide_is_static_render_mode = \Elementor\Plugin::$instance->frontend->is_static_render_mode();
                                                                        $slide_post_id = get_queried_object_id();

                                                                        if ( $slide_is_static_render_mode ) {
                                                                            $slide_video_html = \Elementor\Embed::get_embed_thumbnail_html( $slide_video_url, $slide_post_id );
                                                                        } else if ( 'youtube' !== $slide_video_type ) {
                                                                            $slide_video_html = \Elementor\Embed::get_embed_html( $slide_video_url, $slide_embed_params,
                                                                                $slide_embed_options );
                                                                        }
                                                                    }

                                                                    if ( empty( $slide_video_html ) ) {
                                                                        echo esc_url( $slide_video_url );

                                                                        return;
                                                                    }

                                                                    $this->add_render_attribute( 'video-wrapper', 'class', 'elementor-wrapper' );
                                                                    $this->add_render_attribute( 'video-wrapper', 'class', 'elementor-open-lightbox' );

                                                                    echo '<span class="technum-video-button' . ( !empty($slide_video_button_type) ? ' video-button-type-' . esc_attr
                                                                            ($slide_video_button_type) : '' ) . '">';
                                                                    ?>
                                                                        <span <?php $this->print_render_attribute_string( 'video-wrapper' ); ?>>
                                                                            <?php
                                                                                    if ( 'hosted' === $slide_video_type ) {
                                                                                        $slide_lightbox_url = $slide_video_url;
                                                                                    } else {
                                                                                        $slide_lightbox_url = \Elementor\Embed::get_embed_url( $slide_video_url, $slide_embed_params, $slide_embed_options );
                                                                                    }

                                                                                    $slide_lightbox_options = [
                                                                                        'type'          => 'video',
                                                                                        'videoType'     => $slide_video_type,
                                                                                        'url'           => $slide_lightbox_url,
                                                                                        'modalOptions'  => [
                                                                                            'id'                        => 'elementor-lightbox-' . $this->get_id(),
                                                                                            'videoAspectRatio'          => '169'
                                                                                        ],
                                                                                    ];

                                                                                    $this->add_render_attribute( 'image-overlay', [
                                                                                        'data-elementor-open-lightbox'  => 'yes',
                                                                                        'data-elementor-lightbox'       => wp_json_encode( $slide_lightbox_options ),
                                                                                    ] );

                                                                                    if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                                                                                        $this->add_render_attribute( 'image-overlay', [
                                                                                            'class' => 'elementor-clickable',
                                                                                        ] );
                                                                                    }

                                                                                    ?> <span <?php $this->print_render_attribute_string( 'image-overlay' ); ?>><?php
//                                                                                    echo '<span class="elementor-custom-embed-play" role="button">';
                                                                                        echo '<svg aria-hidden="true" class="progress" width="70" height="70" viewBox="0 0 70 70"><path class="progress__circle" d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z"></path><path class="progress__path" d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z" pathLength="1"></path></svg>';
                                                                                        if ( !empty($video_button_text) ) {
                                                                                            echo '<span class="technum-video-button-text">' . esc_html($video_button_text) . '</span>';
                                                                                        }
//                                                                                    echo '</span>';
                                                                                ?> </span><?php
                                                                            ?>
                                                                        </span>
                                                                    <?php
                                                                echo '</span>';
                                                            }


                                                        echo '</div>';
                                                    echo '</div>';
                                                }



                                            echo '</div>';

                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';

                                if ( !empty($slide['additional_image']) ) {
                                    echo '<div class="slide-image-column">';
                                        echo '<div class="additional-image tilt-effect">' .
                                        wp_get_attachment_image( $slide['additional_image']['id'], 'full' ) . '</div>';
                                    echo '</div>';
                                }

                            echo '</div>';
                        }
                        ?>
                    </div>
                    <?php
                        if ( $add_socials == 'yes' || ( $settings['dots'] == 'yes' && $settings['dots_position'] != 'bottom' ) ) {
                            echo '<div class="aside-area aside-area-position-' . ( !empty($settings['dots_position']) ? esc_attr($settings['dots_position']) : 'left' ) . '">';
                            if ( $settings['dots'] == 'yes' && $settings['dots_position'] != 'bottom' ) {
                                echo '<div class="owl-dots' . (!empty($widget_id) ? ' owl-dots-' . esc_attr($widget_id) : '') . '"></div>';
                            }
                            if ( $add_socials == 'yes' ) {
                                echo technum_socials_output('content-slider-socials wrapper-socials');
                            }
                            echo '</div>';
                        }

                        if (
                            $add_contacts == 'yes' ||
                            (
                                $settings['dots'] == 'yes' &&
                                $settings['dots_position'] == 'bottom'
                            ) ||
                            (
                                $add_video == 'yes' && (
                                    ( $video_type == 'youtube' && !empty($youtube_url) ) ||
                                    ( $video_type == 'vimeo' && !empty($vimeo_url) ) ||
                                    ( $video_type == 'dailymotion' && !empty($dailymotion_url) ) ||
                                    ( $video_type == 'hosted' && (
                                            !empty($insert_url) ||
                                            !empty($hosted_url) ||
                                            !empty($external_url)
                                        ) )
                                )
                            )
                        ) {
                            echo '<div class="bottom-area">';
                            if ( $add_video == 'yes' && (
                                    ( $video_type == 'youtube' && !empty($youtube_url) ) ||
                                    ( $video_type == 'vimeo' && !empty($vimeo_url) ) ||
                                    ( $video_type == 'dailymotion' && !empty($dailymotion_url) ) ||
                                    ( $video_type == 'hosted' && (
                                            !empty($insert_url) ||
                                            !empty($hosted_url) ||
                                            !empty($external_url)
                                        ) )
                                ) ) {
                                $video_url = $settings[ $settings['video_type'] . '_url' ];

                                if ( 'hosted' === $settings['video_type'] ) {
                                    $video_url = $this->get_hosted_video_url();
                                } else {
                                    $embed_params = $this->get_embed_params();
                                    $embed_options = $this->get_embed_options();
                                }

                                if ( 'youtube' === $settings['video_type'] ) {
                                    $video_html = '<div class="elementor-video"></div>';
                                }

                                if ( 'hosted' === $settings['video_type'] ) {
                                    $this->add_render_attribute( 'video-wrapper', 'class', 'e-hosted-video' );

                                    ob_start();

                                    $this->render_hosted_video();

                                    $video_html = ob_get_clean();
                                } else {
                                    $is_static_render_mode = \Elementor\Plugin::$instance->frontend->is_static_render_mode();
                                    $post_id = get_queried_object_id();

                                    if ( $is_static_render_mode ) {
                                        $video_html = \Elementor\Embed::get_embed_thumbnail_html( $video_url, $post_id );
                                    } else if ( 'youtube' !== $settings['video_type'] ) {
                                        $video_html = \Elementor\Embed::get_embed_html( $video_url, $embed_params, $embed_options );
                                    }
                                }

                                if ( empty( $video_html ) ) {
                                    echo esc_url( $video_url );

                                    return;
                                }

                                $this->add_render_attribute( 'video-wrapper', 'class', 'elementor-wrapper' );

                                $this->add_render_attribute( 'video-wrapper', 'class', 'elementor-open-lightbox' );
                                ?>
                                <div class="content-slider-video">
                                    <div <?php $this->print_render_attribute_string( 'video-wrapper' ); ?>>
                                    <?php
                                        if ( $this->has_image_overlay() ) {
                                            $this->add_render_attribute( 'image-overlay', 'class', 'elementor-custom-embed-image-overlay' );

                                            if ( 'hosted' === $settings['video_type'] ) {
                                                $lightbox_url = $video_url;
                                            } else {
                                                $lightbox_url = \Elementor\Embed::get_embed_url( $video_url, $embed_params, $embed_options );
                                            }

                                            $lightbox_options = [
                                                'type'          => 'video',
                                                'videoType'     => $settings['video_type'],
                                                'url'           => $lightbox_url,
                                                'modalOptions'  => [
                                                    'id'                        => 'elementor-lightbox-' . $this->get_id(),
                                                    'videoAspectRatio'          => '169'
                                                ],
                                            ];

                                            $this->add_render_attribute( 'image-overlay', [
                                                'data-elementor-open-lightbox'  => 'yes',
                                                'data-elementor-lightbox'       => wp_json_encode( $lightbox_options ),
                                            ] );

                                            if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                                                $this->add_render_attribute( 'image-overlay', [
                                                    'class' => 'elementor-clickable',
                                                ] );
                                            }

                                            ?>
                                            <div <?php $this->print_render_attribute_string( 'image-overlay' ); ?>>
                                                <?php Group_Control_Image_Size::print_attachment_image_html( $settings, 'image_overlay' ); ?>
                                                <div class="elementor-custom-embed-play" role="button">
                                                    <i class="eicon-play" aria-hidden="true"></i>
                                                    <span class="elementor-screen-only"><?php esc_html_e( 'Play Video', 'technum_plugin' ); ?></span>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>

                                <?php
                            }
                            if (
                                $add_contacts == 'yes' && (
                                    !empty($contact_email_title) ||
                                    !empty($contact_email_text) ||
                                    !empty($contact_phone_title) ||
                                    !empty($contact_phone_text) ||
                                    !empty($contact_address_title) ||
                                    !empty($contact_address_text)
                                )
                            ) {
                                echo '<div class="content-slider-contacts contacts">';
                                if ( !empty($contact_email_title) || !empty($contact_email_text) ) {
                                    echo '<div class="contact-item contact-item-email">';
                                    echo ( !empty($contact_email_title) ? '<div class="contact-item-title">' . esc_html($contact_email_title) . '</div>' : '' );
                                    echo ( !empty($contact_email_text) ? '<div class="contact-item-text">' . wp_kses_post($contact_email_text) . '</div>' : '' );
                                    echo '</div>';
                                }
                                if ( !empty($contact_phone_title) || !empty($contact_phone_text) ) {
                                    echo '<div class="contact-item contact-item-phone">';
                                    echo ( !empty($contact_phone_title) ? '<div class="contact-item-title">' . esc_html($contact_phone_title) . '</div>' : '' );
                                    echo ( !empty($contact_phone_text) ? '<div class="contact-item-text">' . wp_kses_post($contact_phone_text) . '</div>' : '' );
                                    echo '</div>';
                                }
                                if ( !empty($contact_address_title) || !empty($contact_address_text) ) {
                                    echo '<div class="contact-item contact-item-address">';
                                    echo ( !empty($contact_address_title) ? '<div class="contact-item-title">' . esc_html($contact_address_title) . '</div>' : '' );
                                    echo ( !empty($contact_address_text) ? '<div class="contact-item-text">' . wp_kses_post($contact_address_text) . '</div>' : '' );
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            if ( $settings['dots'] == 'yes' && $settings['dots_position'] == 'bottom' ) {
                                echo '<div class="owl-dots' . (!empty($widget_id) ? ' owl-dots-' . esc_attr($widget_id) : '') . '"></div>';
                            }
                            echo '</div>';
                        }
                    ?>
                </div>

            </div>
        </div>
        <?php
    }

    protected function content_template() {}

    public function render_plain_content() {
        $settings = $this->get_settings_for_display();
        if ( 'hosted' !== $settings['video_type'] ) {
            $url = $settings[ $settings['video_type'] . '_url' ];
        } else {
            $url = $this->get_hosted_video_url();
        }
        echo esc_url( $url );
    }

    public function get_embed_params() {
        $settings = $this->get_settings_for_display();
        $params = [];
        $params_dictionary = [];
        if ( 'youtube' === $settings['video_type'] ) {
            $params_dictionary = [];
            $params['wmode'] = 'opaque';
        } elseif ( 'vimeo' === $settings['video_type'] ) {
            $params_dictionary = [
                'mute'              => 'muted',
                'vimeo_title'       => 'title',
                'vimeo_portrait'    => 'portrait',
                'vimeo_byline'      => 'byline'
            ];
            $params['color'] = str_replace( '#', '', $settings['color'] );
            $params['autopause'] = '0';
        } elseif ( 'dailymotion' === $settings['video_type'] ) {
            $params_dictionary = [
                'showinfo'  => 'ui-start-screen-info',
                'logo'      => 'ui-logo',
            ];
            $params['ui-highlight'] = str_replace( '#', '', $settings['color'] );
            $params['endscreen-enable'] = '0';
        }
        foreach ( $params_dictionary as $key => $param_name ) {
            $setting_name = $param_name;
            if ( is_string( $key ) ) {
                $setting_name = $key;
            }
            $setting_value = $settings[ $setting_name ] ? '1' : '0';
            $params[ $param_name ] = $setting_value;
        }

        return $params;
    }

    protected function has_image_overlay() {
        $settings = $this->get_settings_for_display();
        return ! empty( $settings['image_overlay']['url'] );
    }

    private function get_embed_options() {
        $settings = $this->get_settings_for_display();
        $embed_options = [];
        if ( 'youtube' === $settings['video_type'] ) {
            $embed_options['privacy'] = 'no';
        }

        return $embed_options;
    }

    private function get_hosted_video_url() {
        $settings = $this->get_settings_for_display();
        if ( ! empty( $settings['insert_url'] ) ) {
            $video_url = $settings['external_url']['url'];
        } else {
            $video_url = $settings['hosted_url']['url'];
        }
        if ( empty( $video_url ) ) {
            return '';
        }

        return $video_url;
    }

    private function render_hosted_video() {
        $video_url = $this->get_hosted_video_url();
        if ( empty( $video_url ) ) {
            return;
        }
        $video_params = [];
        ?>
        <video class="elementor-video" src="<?php echo esc_url( $video_url ); ?>" <?php Utils::print_html_attributes( $video_params ); ?>></video>
        <?php
    }
}
