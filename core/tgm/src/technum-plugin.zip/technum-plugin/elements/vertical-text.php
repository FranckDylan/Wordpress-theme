<?php

/*
 * Created by Artureanec
*/

namespace TechnUm\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class TechnUm_Vertical_Text_Widget extends Widget_Base {

    public function get_name() {
        return 'technum_vertical_text';
    }

    public function get_title() {
        return esc_html__('Vertical Text', 'technum_plugin');
    }

    public function get_icon() {
        return 'eicon-t-letter';
    }

    public function get_categories() {
        return ['technum_widgets'];
    }

    protected function register_controls() {

        // ----------------------------- //
        // ---------- Content ---------- //
        // ----------------------------- //
        $this->start_controls_section(
            'section_vertical_text',
            [
                'label' => esc_html__('Vertical Text', 'technum_plugin')
            ]
        );

        $this->add_control(
            'text',
            [
                'label'         => esc_html__( 'Text', 'technum_plugin' ),
                'type'          => Controls_Manager::WYSIWYG
            ]
        );

        $this->end_controls_section();

        // ----------------------------------- //
        // ---------- Text Settings ---------- //
        // ----------------------------------- //
        $this->start_controls_section(
            'section_text_settings',
            [
                'label' => esc_html__('Text Settings', 'technum_plugin'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'text_typography',
                'label'     => esc_html__('Text Typography', 'technum_plugin'),
                'selector'  => '{{WRAPPER}} .vertical-text'
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'     => esc_html__('Text Color', 'technum_plugin'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vertical-text' => 'color: {{VALUE}};'
                ]
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings       = $this->get_settings();
        $text           = $settings['text'];

        $block_classes  = 'vertical-text';

        // ------------------------------------ //
        // ---------- Widget Content ---------- //
        // ------------------------------------ //
        if ( !empty($text) ) {
            echo '<div class="' . esc_attr($block_classes) . '">';
                echo wp_kses($text, array(
                    'br'        => array(),
                    'span'      => array(
                        'style'     => true
                    ),
                    'a'         => array(
                        'href'      => true,
                        'target'    => true
                    ),
                    'img'       => array(
                        'src'       => true,
                        'srcset'    => true,
                        'sizes'     => true,
                        'class'     => true,
                        'alt'       => true,
                        'title'     => true
                    ),
                    'em'        => array(),
                    'strong'    => array(),
                    'del'       => array()
                ));
            echo '</div>';
        }
    }

    protected function content_template() {}

    public function render_plain_content() {}
}